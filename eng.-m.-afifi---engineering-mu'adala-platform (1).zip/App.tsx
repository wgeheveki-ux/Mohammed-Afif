
import React, { useState, useEffect, useMemo } from 'react';
import { HashRouter, Routes, Route, Link, useNavigate, useLocation } from 'react-router-dom';
import { 
  Menu, X, Globe, User, BookOpen,
  LogOut, Sun, Moon, Layout, ShieldAlert,
  Facebook, Instagram, Youtube, Twitter, MessageCircle, Mail, Phone,
  LayoutDashboard, Sparkles, ShieldCheck
} from 'lucide-react';
import { Language, User as UserType } from './types';
import { TRANSLATIONS } from './constants';
import Home from './pages/Home';
import Lessons from './pages/Lessons';
import LessonDetail from './pages/LessonDetail';
import QuizPage from './pages/QuizPage';
import AuthPage from './pages/AuthPage';
import AdminDashboard from './pages/AdminDashboard';
import Dashboard from './pages/Dashboard';
import UnavailableContent from './pages/UnavailableContent';
import HowTo from './pages/HowTo';
import Pricing from './pages/Pricing';

// نظام الحماية الاستباقي - Proactive Imperial Guard
const ImperialGuard: React.FC<{ user: UserType | null }> = ({ user }) => {
  const [isBlurred, setIsBlurred] = useState(false);

  useEffect(() => {
    // 1. منع الزر الأيمن للفأرة
    const handleContextMenu = (e: MouseEvent) => e.preventDefault();
    
    // 2. منع الاختصارات المشبوهة واكتشاف PrintScreen
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'F12') e.preventDefault();
      if (e.ctrlKey && e.shiftKey && ['I', 'J', 'C'].includes(e.key.toUpperCase())) e.preventDefault();
      if (e.ctrlKey && e.key.toUpperCase() === 'U') e.preventDefault();
      if (e.ctrlKey && e.key.toUpperCase() === 'P') e.preventDefault();
      
      // بمجرد الضغط على زر تصوير الشاشة، نغلق الشاشة فوراً
      if (e.key === 'PrintScreen' || e.key === 'Snapshot') {
        setIsBlurred(true);
        e.preventDefault();
      }
    };

    // 3. الحماية الاستباقية: التعتيم بمجرد خروج الماوس من النافذة
    // هذا يمنع الطالب من الذهاب لأدوات مثل Snipping Tool أو برامج التسجيل
    const handleMouseLeave = () => setIsBlurred(true);
    const handleMouseEnter = () => setIsBlurred(false);

    // 4. الحماية عند فقدان التركيز (تفعيل لحظي)
    const handleVisibilityChange = () => {
      if (document.hidden) setIsBlurred(true);
    };

    const handleWindowBlur = () => setIsBlurred(true);
    const handleWindowFocus = () => setIsBlurred(false);

    window.addEventListener('contextmenu', handleContextMenu);
    window.addEventListener('keydown', handleKeyDown);
    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('blur', handleWindowBlur);
    window.addEventListener('focus', handleWindowFocus);
    
    // إضافة مستشعرات خروج الماوس للحماية الاستباقية
    document.addEventListener('mouseleave', handleMouseLeave);
    document.addEventListener('mouseenter', handleMouseEnter);

    return () => {
      window.removeEventListener('contextmenu', handleContextMenu);
      window.removeEventListener('keydown', handleKeyDown);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('blur', handleWindowBlur);
      window.removeEventListener('focus', handleWindowFocus);
      document.removeEventListener('mouseleave', handleMouseLeave);
      document.removeEventListener('mouseenter', handleMouseEnter);
    };
  }, []);

  if (isBlurred) {
    return (
      <div className="fixed inset-0 z-[99999] bg-gray-950/90 backdrop-blur-3xl flex items-center justify-center p-10 text-center transition-opacity duration-0">
        <div className="max-w-md space-y-8 animate-in zoom-in duration-150">
          <div className="w-28 h-28 bg-blue-600 rounded-[2.5rem] flex items-center justify-center mx-auto shadow-[0_0_50px_rgba(37,99,235,0.4)] border-4 border-blue-500/50">
            <ShieldCheck size={56} className="text-white animate-pulse" />
          </div>
          <div className="space-y-4">
            <h2 className="text-4xl font-black text-white tracking-tighter">نظام حماية الإمبراطورية</h2>
            <p className="text-blue-200 font-bold text-lg leading-relaxed">
              توقف! النظام استشعر محاولة تصوير أو خروج من المحتوى. <br/>
              <span className="text-sm text-gray-400 mt-4 block">يرجى إبقاء الماوس داخل النافذة وإغلاق كافة برامج التسجيل للمتابعة.</span>
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      {/* العلامة المائية الديناميكية المتحركة */}
      {user && (
        <div className="fixed inset-0 pointer-events-none z-[9999] overflow-hidden select-none opacity-[0.04] dark:opacity-[0.08]">
          <div className="absolute top-0 left-0 w-full h-full animate-watermark-move flex items-center justify-center">
            <div className="flex flex-col items-center">
               <span className="text-4xl font-black rotate-[-45deg] whitespace-nowrap">{user.name}</span>
               <span className="text-2xl font-black rotate-[-45deg] mt-4">{user.email}</span>
            </div>
          </div>
          <div className="absolute top-1/4 left-1/4 animate-watermark-move" style={{ animationDelay: '-7s' }}>
             <span className="text-3xl font-black rotate-[20deg]">{user.id}</span>
          </div>
        </div>
      )}
    </>
  );
};

const SessionGuardian: React.FC<{ user: UserType | null, setUser: (u: UserType | null) => void, lang: Language }> = ({ user, setUser, lang }) => {
  const [isSessionInvalid, setIsSessionInvalid] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (!user) return;
    const checkInterval = setInterval(() => {
      const activeSessionKey = `active_session_${user.id}`;
      const latestSessionId = localStorage.getItem(activeSessionKey);
      if (latestSessionId && user.sessionId && latestSessionId !== user.sessionId) {
        setIsSessionInvalid(true);
      }
    }, 2000);
    return () => clearInterval(checkInterval);
  }, [user]);

  if (isSessionInvalid) {
    return (
      <div className="fixed inset-0 z-[10000] bg-gray-950/95 backdrop-blur-xl flex items-center justify-center p-6 text-center text-white overflow-hidden animate-in fade-in duration-300">
        <div className="max-w-md w-full space-y-8 relative z-10 animate-in zoom-in duration-500">
           <div className="w-24 h-24 bg-red-600 rounded-[2rem] flex items-center justify-center mx-auto border-4 border-red-500/50 shadow-[0_0_50px_rgba(239,68,68,0.4)]">
              < ShieldAlert size={48} className="text-white animate-pulse" />
           </div>
           <div className="space-y-4">
              <h2 className="text-3xl font-black">{lang === 'ar' ? 'تنبيه الأمان' : 'Security Alert'}</h2>
              <p className="text-sm font-medium leading-relaxed opacity-90">
                {lang === 'ar' ? 'تم رصد دخول من جهاز آخر. قوانين الإمبراطورية تسمح بجهاز واحد فقط!' : 'Multiple logins detected. Only one session allowed per student!'}
              </p>
           </div>
           <button onClick={() => { setUser(null); setIsSessionInvalid(false); navigate('/auth'); }} className="w-full bg-blue-700 text-white py-4 rounded-2xl font-black text-lg hover:bg-blue-800 transition-all shadow-2xl active:scale-95">
             {lang === 'ar' ? 'العودة لتسجيل الدخول' : 'Back to Login'}
           </button>
        </div>
      </div>
    );
  }
  return null;
};

const AppContent: React.FC = () => {
  const [lang, setLang] = useState<Language>(Language.AR);
  const [user, setUser] = useState<UserType | null>(() => {
    const saved = localStorage.getItem('afifi_user');
    return saved ? JSON.parse(saved) : null;
  });
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(() => localStorage.getItem('theme') === 'dark');
  const location = useLocation();
  const navigate = useNavigate();

  const t = useMemo(() => TRANSLATIONS[lang], [lang]);
  const isRTL = lang === Language.AR;
  const LOGO_URL = "https://i.ibb.co/6JH2hqLC/JPEG-6137224863898630761.jpg";

  useEffect(() => {
    document.documentElement.dir = isRTL ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  }, [lang, isRTL]);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [isDarkMode]);

  const handleSetUser = (u: UserType | null) => {
    setUser(u);
    if (u) localStorage.setItem('afifi_user', JSON.stringify(u));
    else localStorage.removeItem('afifi_user');
  };

  const handleLogout = () => {
    handleSetUser(null);
    navigate('/');
  };

  const toggleLang = () => setLang(prev => prev === Language.AR ? Language.EN : Language.AR);
  const toggleDarkMode = () => setIsDarkMode(prev => !prev);

  const navLinks = [
    { name: t.home, path: '/', icon: Layout },
    { name: t.courses, path: '/lessons', icon: BookOpen },
    ...(user ? [{ name: t.dashboard, path: '/dashboard', icon: LayoutDashboard }] : []),
  ];

  return (
    <div className={`min-h-screen transition-colors duration-300 ${isDarkMode ? 'dark' : ''} bg-gray-50 dark:bg-gray-950`}>
      <ImperialGuard user={user} />
      <SessionGuardian user={user} setUser={handleSetUser} lang={lang} />
      
      <a 
        href="https://wa.me/201100448213" 
        target="_blank" 
        rel="noopener noreferrer"
        className="fixed bottom-8 left-8 z-[60] w-16 h-16 bg-green-500 text-white rounded-full flex items-center justify-center shadow-2xl hover:bg-green-600 hover:scale-110 transition-all animate-bounce active:scale-90"
      >
        <MessageCircle size={32} />
      </a>

      {location.pathname !== '/admin' && (
        <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 dark:bg-gray-900/80 backdrop-blur-xl border-b border-gray-100 dark:border-gray-800 transition-colors duration-300">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-20">
              <div className="flex items-center gap-8">
                <Link to="/" className="flex items-center gap-3 group">
                  <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center overflow-hidden shadow-xl border-2 border-blue-50 group-hover:border-blue-500 transition-all">
                    <img src={LOGO_URL} alt="Afifi Logo" className="w-full h-full object-cover" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-xl font-black text-blue-900 dark:text-white tracking-tight leading-tight">{t.brand}</span>
                    <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400 uppercase tracking-widest">{lang === 'ar' ? 'إمبراطورية الرياضيات' : 'Math Empire'}</span>
                  </div>
                </Link>
                <div className="hidden md:flex items-center gap-1">
                  {navLinks.map(link => (
                    <Link 
                      key={link.path} 
                      to={link.path} 
                      className={`px-5 py-2.5 rounded-xl text-sm font-bold transition-all flex items-center gap-2 ${
                        location.pathname === link.path ? 'bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400' : 'text-gray-500 dark:text-gray-400 hover:text-blue-600'
                      }`}
                    >
                      <link.icon size={18} />
                      {link.name}
                    </Link>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-3">
                <button onClick={toggleDarkMode} className="p-3 text-gray-500 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-2xl transition-all">
                  {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
                </button>
                <button onClick={toggleLang} className="hidden lg:flex items-center gap-2 px-5 py-2.5 bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-200 rounded-2xl font-bold text-sm hover:bg-gray-200 transition-all">
                  <Globe size={18} className="text-blue-600" />
                  {t.switchLang}
                </button>
                {user ? (
                  <div className="flex items-center gap-3 pl-3 border-l dark:border-gray-800">
                     {user.role === 'admin' && (
                       <Link to="/admin" className="p-3 bg-amber-100 dark:bg-amber-900/30 text-amber-700 rounded-2xl shadow-inner">
                         <Sparkles size={20} />
                       </Link>
                     )}
                     <div className="flex items-center gap-3 p-1.5 pr-4 bg-blue-700 text-white rounded-2xl shadow-xl shadow-blue-500/20">
                        <span className="text-sm font-black hidden sm:inline">{user.name.split(' ')[0]}</span>
                        <div className="w-9 h-9 bg-white/20 rounded-xl flex items-center justify-center text-white"><User size={18} /></div>
                     </div>
                     <button onClick={handleLogout} className="p-2 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-xl transition-all">
                        <LogOut size={20} />
                     </button>
                  </div>
                ) : (
                  <Link to="/auth" className="flex items-center gap-2 px-6 py-3 bg-blue-700 text-white rounded-2xl font-black text-sm shadow-xl shadow-blue-500/30 hover:bg-blue-800 transition-all">
                    <User size={18} />
                    {t.login}
                  </Link>
                )}
                <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="md:hidden p-3 text-blue-900 dark:text-white bg-blue-50 dark:bg-blue-900/20 rounded-2xl">
                  {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
                </button>
              </div>
            </div>
          </div>
          {isMenuOpen && (
            <div className="md:hidden bg-white dark:bg-gray-900 border-t dark:border-gray-800 p-6 space-y-4 animate-in slide-in-from-top duration-300">
              {navLinks.map(link => (
                <Link key={link.path} to={link.path} onClick={() => setIsMenuOpen(false)} className="flex items-center gap-4 p-4 rounded-2xl font-bold text-gray-700 dark:text-gray-200 bg-gray-50 dark:bg-gray-800 hover:bg-blue-50 transition-all">
                  <link.icon size={20} className="text-blue-600" />
                  {link.name}
                </Link>
              ))}
              <button onClick={() => { toggleLang(); setIsMenuOpen(false); }} className="w-full flex items-center gap-4 p-4 rounded-2xl font-bold text-blue-700 dark:text-blue-400 bg-blue-50 dark:bg-blue-900/30">
                <Globe size={20} />
                {t.switchLang}
              </button>
            </div>
          )}
        </nav>
      )}

      <main className={location.pathname === '/admin' ? '' : 'pt-20'}>
        <Routes>
          <Route path="/" element={<Home t={t} lang={lang} user={user} />} />
          <Route path="/lessons" element={<Lessons t={t} lang={lang} user={user} />} />
          <Route path="/lesson/:id" element={<LessonDetail t={t} lang={lang} user={user} />} />
          <Route path="/quiz/:id" element={<QuizPage t={t} lang={lang} />} />
          <Route path="/auth" element={<AuthPage t={t} lang={lang} setUser={handleSetUser} />} />
          <Route path="/admin" element={<AdminDashboard t={t} lang={lang} />} />
          <Route path="/dashboard" element={<Dashboard t={t} lang={lang} user={user} />} />
          <Route path="/unavailable" element={<UnavailableContent t={t} lang={lang} />} />
          <Route path="/how-to" element={<HowTo t={t} lang={lang} />} />
          <Route path="/pricing" element={<Pricing t={t} lang={lang} />} />
        </Routes>
      </main>

      {location.pathname !== '/admin' && (
        <footer className="bg-white dark:bg-gray-900 border-t dark:border-gray-800 pt-20 pb-10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12 mb-16">
              <div className="space-y-6">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center overflow-hidden border-2 border-gray-100 dark:border-gray-800 shadow-xl">
                    <img src={LOGO_URL} alt="Logo" className="w-full h-full object-cover" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-2xl font-black text-blue-900 dark:text-white leading-none">{t.brand}</span>
                    <span className="text-[10px] font-black text-blue-600 uppercase tracking-tighter">Legacy of Mathematics</span>
                  </div>
                </div>
                <p className="text-gray-500 dark:text-gray-400 text-sm font-bold leading-relaxed">
                  الإمبراطورية التعليمية الأقوى في مصر لشرح رياضيات معادلة كلية الهندسة. نحن لا نعلم فقط، نحن نضمن لك التفوق.
                </p>
                <div className="flex items-center gap-3">
                  {[Facebook, Instagram, Youtube, Twitter].map((Icon, i) => (
                    <button key={i} className="w-10 h-10 bg-gray-100 dark:bg-gray-800 rounded-xl flex items-center justify-center text-gray-500 hover:bg-blue-700 hover:text-white transition-all shadow-sm">
                      <Icon size={18} />
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="font-black text-blue-900 dark:text-white mb-8 text-lg underline decoration-blue-500 decoration-4 underline-offset-8">خريطة الإمبراطورية</h4>
                <ul className="space-y-4">
                  <li><Link to="/pricing" className="text-gray-500 dark:text-gray-400 font-bold hover:text-blue-700 transition-colors">عضوية النخبة</Link></li>
                  <li><Link to="/how-to" className="text-gray-500 dark:text-gray-400 font-bold hover:text-blue-700 transition-colors">كيف تصبح مهندساً؟</Link></li>
                  <li><Link to="/auth" className="text-gray-500 dark:text-gray-400 font-bold hover:text-blue-700 transition-colors">بوابة الطلاب</Link></li>
                </ul>
              </div>
              <div>
                <h4 className="font-black text-blue-900 dark:text-white mb-8 text-lg underline decoration-blue-500 decoration-4 underline-offset-8">تواصل مع العفيفي</h4>
                <ul className="space-y-5">
                  <li className="flex items-center gap-3 text-gray-500 dark:text-gray-400 font-black"><Phone size={18} className="text-blue-600" /> +20 11 00448213</li>
                  <li className="flex items-center gap-3 text-gray-500 dark:text-gray-400 font-black"><Mail size={18} className="text-blue-600" /> office@afifi-empire.com</li>
                </ul>
              </div>
            </div>
            <div className="pt-10 border-t border-gray-100 dark:border-gray-800 flex flex-col md:flex-row items-center justify-between gap-6">
              <p className="text-gray-400 text-xs font-black uppercase tracking-widest">&copy; {new Date().getFullYear()} Eng. M. Afifi Math Empire. All Rights Reserved.</p>
            </div>
          </div>
        </footer>
      )}
    </div>
  );
};

const App: React.FC = () => {
  return (
    <HashRouter>
      <AppContent />
    </HashRouter>
  );
};

export default App;
