
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Mail, Lock, User, ShieldCheck, ChevronRight, AlertCircle, Info } from 'lucide-react';
import { Language, User as UserType } from '../types';

interface AuthPageProps {
  t: any;
  lang: Language;
  setUser: any;
}

const AuthPage: React.FC<AuthPageProps> = ({ t, lang, setUser }) => {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const LOGO_URL = "https://i.ibb.co/6JH2hqLC/JPEG-6137224863898630761.jpg";

  const loginWithSession = (userData: UserType) => {
    const newSessionId = Math.random().toString(36).substring(2, 15) + Date.now();
    localStorage.setItem(`active_session_${userData.id}`, newSessionId);
    setUser({ ...userData, sessionId: newSessionId });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Admin Credentials Updated per Request
    if (email === 'Afifa@gamil.com' && password === 'Afifa123456') {
      const adminUser: UserType = {
        id: 'admin-001',
        name: 'Eng. M. Afifi',
        email: 'Afifa@gamil.com',
        isPremium: true,
        role: 'admin',
        progress: {
          completedLessons: [],
          quizScores: {},
          totalPoints: 9999
        }
      };
      loginWithSession(adminUser);
      navigate('/admin');
      return;
    }

    // Normal User Mock Login
    if (mode === 'login') {
      if (!email.includes('@')) {
        setError('يرجى إدخال بريد إلكتروني صحيح');
        return;
      }
      const studentUser: UserType = {
        id: 'u1',
        name: name || 'أحمد طالب',
        email,
        isPremium: false,
        role: 'student',
        progress: {
          completedLessons: ['1'],
          quizScores: { '1': 85 },
          totalPoints: 1250
        }
      };
      loginWithSession(studentUser);
      navigate('/dashboard');
    } else {
      const newUser: UserType = {
        id: 'u2',
        name: name,
        email,
        isPremium: false,
        role: 'student',
        progress: {
          completedLessons: [],
          quizScores: {},
          totalPoints: 0
        }
      };
      loginWithSession(newUser);
      navigate('/dashboard');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex items-center justify-center p-4 transition-colors">
      <div className="max-w-md w-full bg-white dark:bg-gray-900 rounded-[2rem] shadow-2xl shadow-blue-100 dark:shadow-none overflow-hidden border dark:border-gray-800">
        <div className="p-10">
          <div className="text-center mb-10 space-y-4">
             <div className="w-20 h-20 bg-white rounded-3xl flex items-center justify-center overflow-hidden mx-auto shadow-xl border border-gray-100 dark:border-gray-800">
                <img src={LOGO_URL} alt="Logo" className="w-full h-full object-cover" />
             </div>
             <h2 className="text-3xl font-black text-blue-900 dark:text-white">{mode === 'login' ? 'مرحباً بك مجدداً' : 'إنشاء حساب جديد'}</h2>
             <p className="text-gray-500 dark:text-gray-400">منصة المهندس محمد عفيفي للرياضيات</p>
          </div>

          <div className="mb-6 p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-100 dark:border-blue-900/50 rounded-2xl flex items-start gap-3">
             <Info size={18} className="text-blue-600 dark:text-blue-400 mt-1 flex-shrink-0" />
             <p className="text-[11px] font-bold text-blue-700 dark:text-blue-300 leading-relaxed">
               {lang === 'ar' 
                 ? 'تنبيه: لأمانك، يُسمح بتسجيل الدخول من جهاز واحد فقط. تسجيل الدخول من جهاز جديد سيغلق الجلسة النشطة في الأجهزة الأخرى.' 
                 : 'Note: For security, login is allowed on one device at a time. Logging in from a new device will terminate other active sessions.'}
             </p>
          </div>

          {error && (
            <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-900/50 rounded-2xl flex items-center gap-3 text-red-600 dark:text-red-400 text-sm font-bold animate-in shake">
              <AlertCircle size={18} />
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            {mode === 'register' && (
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700 dark:text-gray-300">الاسم بالكامل</label>
                <div className="relative">
                  <User className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                  <input 
                    type="text" 
                    required
                    placeholder="أدخل اسمك الحقيقي"
                    className="w-full bg-gray-50 dark:bg-gray-800 border-none ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-2 focus:ring-blue-500 rounded-2xl py-4 pr-12 pl-4 transition-all dark:text-white font-bold"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </div>
              </div>
            )}

            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-700 dark:text-gray-300">البريد الإلكتروني</label>
              <div className="relative">
                <Mail className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                <input 
                  type="email" 
                  required
                  placeholder="name@example.com"
                  className="w-full bg-gray-50 dark:bg-gray-800 border-none ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-2 focus:ring-blue-500 rounded-2xl py-4 pr-12 pl-4 transition-all dark:text-white font-bold"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold text-gray-700 dark:text-gray-300">كلمة المرور</label>
              <div className="relative">
                <Lock className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                <input 
                  type="password" 
                  required
                  placeholder="••••••••"
                  className="w-full bg-gray-50 dark:bg-gray-800 border-none ring-1 ring-gray-200 dark:ring-gray-700 focus:ring-2 focus:ring-blue-500 rounded-2xl py-4 pr-12 pl-4 transition-all dark:text-white font-bold"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
            </div>

            <button type="submit" className="w-full bg-blue-700 text-white py-5 rounded-2xl font-black text-lg hover:bg-blue-800 shadow-xl shadow-blue-200 dark:shadow-none transition-all flex items-center justify-center gap-2 group">
              {mode === 'login' ? 'دخول' : 'إنشاء الحساب'}
              <ChevronRight className="group-hover:translate-x-1 transition-transform rtl:rotate-180" size={20} />
            </button>
          </form>

          <div className="mt-10 pt-8 border-t border-gray-100 dark:border-gray-800 flex items-center justify-center gap-2 text-sm">
            <span className="text-gray-500 dark:text-gray-400">{mode === 'login' ? 'ليس لديك حساب؟' : 'لديك حساب بالفعل؟'}</span>
            <button 
              onClick={() => setMode(mode === 'login' ? 'register' : 'login')}
              className="text-blue-600 dark:text-blue-400 font-bold hover:underline"
            >
              {mode === 'login' ? 'سجل الآن' : 'سجل دخول'}
            </button>
          </div>
        </div>
        
        <div className="bg-gray-50 dark:bg-gray-800/50 p-6 flex items-center justify-center gap-3 text-xs text-gray-400 font-bold uppercase tracking-widest">
           <ShieldCheck size={16} />
           <span>نظام مشفر بالكامل وآمن</span>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;
