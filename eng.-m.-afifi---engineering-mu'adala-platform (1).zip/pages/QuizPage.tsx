
import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { CheckCircle, AlertTriangle, Trophy, ChevronRight, Clock, Award } from 'lucide-react';
import { Language } from '../types';

interface QuizPageProps {
  t: any;
  lang: Language;
}

const QuizPage: React.FC<QuizPageProps> = ({ t, lang }) => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [timeLeft, setTimeLeft] = useState(300); // 5 minutes

  // Mock Questions
  const questions = [
    {
      text: { ar: 'ما هي قيمة س في المعادلة س^2 = 16؟', en: 'What is the value of x in x^2 = 16?' },
      options: [
        { ar: '4 فقط', en: '4 only' },
        { ar: '4 أو -4', en: '4 or -4' },
        { ar: '8', en: '8' },
        { ar: '16', en: '16' }
      ],
      correct: 1
    },
    {
      text: { ar: 'مشتقة س^3 هي:', en: 'The derivative of x^3 is:' },
      options: [
        { ar: '3س', en: '3x' },
        { ar: '3س^2', en: '3x^2' },
        { ar: 'س^2', en: 'x^2' },
        { ar: '3', en: '3' }
      ],
      correct: 1
    }
  ];

  useEffect(() => {
    if (timeLeft > 0 && !showResult) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0) {
      setShowResult(true);
    }
  }, [timeLeft, showResult]);

  const handleAnswer = (index: number) => {
    if (index === questions[currentQuestion].correct) {
      setScore(score + 1);
    }

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setShowResult(true);
    }
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  if (showResult) {
    const percentage = (score / questions.length) * 100;
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-950 flex items-center justify-center p-4 transition-colors duration-300">
        <div className="max-w-xl w-full bg-white dark:bg-gray-900 rounded-[3rem] shadow-2xl p-12 text-center space-y-8 animate-in zoom-in duration-300 border dark:border-gray-800">
           <div className={`w-32 h-32 rounded-full flex items-center justify-center mx-auto shadow-xl ${percentage >= 50 ? 'bg-green-100 dark:bg-green-900/30 text-green-600' : 'bg-red-100 dark:bg-red-900/30 text-red-600'}`}>
              {percentage >= 50 ? <Trophy size={64} /> : <AlertTriangle size={64} />}
           </div>
           
           <div className="space-y-2">
             <h2 className="text-4xl font-black text-blue-900 dark:text-white">
               {percentage >= 50 ? 'ممتاز، لقد اجتزت!' : 'حظ موفق المرة القادمة'}
             </h2>
             <p className="text-gray-500 dark:text-gray-400 font-bold text-lg">نتيجتك هي {percentage}%</p>
           </div>

           <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-50 dark:bg-gray-800/50 p-6 rounded-3xl">
                 <div className="text-2xl font-black text-blue-900 dark:text-blue-400">{score}</div>
                 <div className="text-xs text-gray-500 dark:text-gray-500 font-bold uppercase">إجابات صحيحة</div>
              </div>
              <div className="bg-gray-50 dark:bg-gray-800/50 p-6 rounded-3xl">
                 <div className="text-2xl font-black text-blue-900 dark:text-blue-400">{questions.length - score}</div>
                 <div className="text-xs text-gray-500 dark:text-gray-500 font-bold uppercase">إجابات خاطئة</div>
              </div>
           </div>

           {percentage >= 50 && (
             <button className="w-full flex items-center justify-center gap-3 bg-blue-700 text-white py-5 rounded-2xl font-black text-lg hover:bg-blue-800 shadow-xl transition-all">
                <Award />
                تحميل شهادة الإتمام
             </button>
           )}

           <button 
             onClick={() => navigate('/lessons')}
             className="w-full text-blue-700 dark:text-blue-400 font-black py-4 border-2 border-blue-100 dark:border-blue-900/50 rounded-2xl hover:bg-blue-50 dark:hover:bg-gray-800 transition-all"
           >
             العودة لقائمة الدروس
           </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 py-12 px-4 transition-colors duration-300">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
             <div className="w-16 h-16 bg-blue-700 text-white rounded-2xl flex items-center justify-center font-black text-xl shadow-lg">
                {currentQuestion + 1}
             </div>
             <div>
               <h3 className="font-bold text-gray-900 dark:text-white">اختبار الدرس</h3>
               <p className="text-sm text-gray-400 dark:text-gray-500">سؤال {currentQuestion + 1} من {questions.length}</p>
             </div>
          </div>
          
          <div className="flex items-center gap-3 bg-white dark:bg-gray-900 px-6 py-3 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800">
             <Clock className="text-red-500" size={20} />
             <span className={`font-black text-lg ${timeLeft < 60 ? 'text-red-600 animate-pulse' : 'text-gray-700 dark:text-gray-200'}`}>
               {formatTime(timeLeft)}
             </span>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-900 rounded-[2.5rem] shadow-xl border border-gray-100 dark:border-gray-800 overflow-hidden">
           <div className="h-3 bg-gray-100 dark:bg-gray-800 w-full overflow-hidden">
             <div 
               className="h-full bg-blue-600 transition-all duration-500 ease-out"
               style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
             ></div>
           </div>

           <div className="p-12">
             <h2 className="text-2xl font-black text-blue-900 dark:text-white mb-12 leading-relaxed">
               {questions[currentQuestion].text[lang]}
             </h2>

             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               {questions[currentQuestion].options.map((option, idx) => (
                 <button
                   key={idx}
                   onClick={() => handleAnswer(idx)}
                   className="group p-6 bg-gray-50 dark:bg-gray-800/50 rounded-3xl border-2 border-transparent hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-all text-start flex items-center justify-between"
                 >
                   <span className="font-bold text-gray-700 dark:text-gray-300 group-hover:text-blue-900 dark:group-hover:text-white">{option[lang]}</span>
                   <div className="w-6 h-6 rounded-full border-2 border-gray-300 dark:border-gray-600 group-hover:border-blue-500 flex items-center justify-center">
                      <div className="w-3 h-3 bg-blue-500 rounded-full scale-0 group-hover:scale-100 transition-transform"></div>
                   </div>
                 </button>
               ))}
             </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default QuizPage;
