
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  UserPlus, BookOpen, PlayCircle, FileText, 
  CheckSquare, TrendingUp, Sparkles, ChevronRight, ArrowRight,
  Wallet, CreditCard, Smartphone, ShieldCheck
} from 'lucide-react';
import { Language } from '../types';

interface HowToProps {
  t: any;
  lang: Language;
}

const HowTo: React.FC<HowToProps> = ({ t, lang }) => {
  const navigate = useNavigate();
  const isRTL = lang === 'ar';

  const steps = [
    {
      icon: <UserPlus size={32} />,
      title: { ar: '1. إنشاء حسابك الخاص', en: '1. Create Your Account' },
      desc: { 
        ar: 'ابدأ بالتسجيل في المنصة لتتمكن من حفظ تقدمك، الوصول للمحتوى المدفوع، ومتابعة درجاتك في الاختبارات.', 
        en: 'Start by registering to save your progress, access premium content, and track your quiz scores.' 
      },
      color: 'bg-blue-500'
    },
    {
      icon: <Wallet size={32} />,
      title: { ar: '2. طرق الشحن والاشتراك', en: '2. Charging & Subscription' },
      desc: { 
        ar: 'يمكنك الاشتراك عبر (فودافون كاش) بالتحويل للرقم الموضح في صفحة الدفع، أو استخدام (البطاقات البنكية) أو (فوري) لتفعيل فوري لحسابك.', 
        en: 'You can subscribe via (Vodafone Cash) by transferring to the listed number, or use (Bank Cards) or (Fawry) for instant activation.' 
      },
      color: 'bg-green-600'
    },
    {
      icon: <BookOpen size={32} />,
      title: { ar: '3. اختر المادة العلمية', en: '3. Choose Your Subject' },
      desc: { 
        ar: 'تصفح الأقسام الرئيسية (جبر، فراغية، تفاضل، تكامل) واختر الدرس الذي ترغب في مذاكرته اليوم.', 
        en: 'Browse the main sections (Algebra, Geometry, Calculus, Integration) and pick the lesson you want to study.' 
      },
      color: 'bg-indigo-500'
    },
    {
      icon: <PlayCircle size={32} />,
      title: { ar: '4. شاهد وتعلم', en: '4. Watch and Learn' },
      desc: { 
        ar: 'استمتع بمشاهدة فيديوهات الشرح بجودة 4K مع المهندس محمد عفيفي، والتي تبسط أعقد المفاهيم الرياضية.', 
        en: 'Enjoy 4K video explanations with Eng. Mohamed Afifi, simplifying the most complex mathematical concepts.' 
      },
      color: 'bg-purple-500'
    },
    {
      icon: <FileText size={32} />,
      title: { ar: '5. حمل ملخصات الـ PDF', en: '5. Download PDF Summaries' },
      desc: { 
        ar: 'كل درس مرفق بملف PDF يحتوي على ملخص شامل للشرح والتمارين المحلولة لتراجعها في أي وقت.', 
        en: 'Every lesson comes with a PDF containing a full summary and solved exercises for you to review anytime.' 
      },
      color: 'bg-pink-500'
    },
    {
      icon: <CheckSquare size={32} />,
      title: { ar: '6. اختبر نفسك', en: '6. Test Yourself' },
      desc: { 
        ar: 'بعد كل درس، هناك اختبار قصير تفاعلي لتثبيت المعلومة. ستحصل على نتيجتك وتصحيح أخطائك فوراً.', 
        en: 'After each lesson, take an interactive quiz to reinforce your knowledge. Get your score and corrections instantly.' 
      },
      color: 'bg-emerald-500'
    },
    {
      icon: <Sparkles size={32} />,
      title: { ar: '7. اسأل المساعد الذكي', en: '7. Ask the AI Assistant' },
      desc: { 
        ar: 'إذا واجهت أي مسألة صعبة، يمكنك استخدام مساعد Gemini AI المدمج في الموقع للحصول على شرح إضافي فوري.', 
        en: 'If you face a tough problem, use the built-in Gemini AI assistant to get an instant additional explanation.' 
      },
      color: 'bg-yellow-500'
    },
    {
      icon: <TrendingUp size={32} />,
      title: { ar: '8. تابع تقدمك', en: '8. Track Your Progress' },
      desc: { 
        ar: 'لوحة التحكم الخاصة بك تظهر لك الدروس التي أكملتها، وتحليلاً لمستواك لضمان استعدادك الكامل للمعادلة.', 
        en: 'Your personal dashboard shows completed lessons and performance analytics to ensure you are ready for the exam.' 
      },
      color: 'bg-cyan-500'
    }
  ];

  return (
    <div className="bg-white dark:bg-gray-950 min-h-screen transition-colors duration-300">
      {/* Hero Header */}
      <section className="bg-blue-900 dark:bg-gray-900 py-20 text-center text-white relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
           <div className="absolute top-10 left-10 w-64 h-64 bg-white rounded-full blur-3xl"></div>
           <div className="absolute bottom-10 right-10 w-96 h-96 bg-blue-400 rounded-full blur-3xl"></div>
        </div>
        <div className="max-w-4xl mx-auto px-4 relative z-10">
          <h1 className="text-4xl md:text-6xl font-black mb-6">
            {lang === 'ar' ? 'رحلة التفوق مع م/ محمد عفيفي' : 'Your Success Journey with Eng. M. Afifi'}
          </h1>
          <p className="text-xl text-blue-100 dark:text-blue-300 leading-relaxed">
            {lang === 'ar' 
              ? 'تعرف على كيفية استخدام المنصة من التسجيل وحتى الوصول لكلية الهندسة' 
              : 'Learn how to use the platform from registration all the way to Engineering school.'}
          </p>
        </div>
      </section>

      {/* Steps Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="relative">
          {/* Vertical Line for Desktop */}
          <div className="hidden lg:block absolute left-1/2 top-0 bottom-0 w-1 bg-gray-100 dark:bg-gray-800 -translate-x-1/2 rounded-full"></div>

          <div className="space-y-20 lg:space-y-32">
            {steps.map((step, index) => (
              <div key={index} className={`flex flex-col lg:flex-row items-center gap-12 ${index % 2 !== 0 ? 'lg:flex-row-reverse' : ''}`}>
                {/* Image/Icon Side */}
                <div className="flex-1 flex justify-center items-center">
                  <div className={`w-32 h-32 md:w-48 md:h-48 ${step.color} rounded-[3rem] shadow-2xl flex items-center justify-center text-white transform rotate-3 hover:rotate-0 transition-transform duration-500`}>
                    {step.icon}
                  </div>
                </div>

                {/* Content Side */}
                <div className="flex-1 text-center lg:text-start space-y-4">
                  <h3 className="text-2xl md:text-3xl font-black text-blue-900 dark:text-white">
                    {step.title[lang]}
                  </h3>
                  <p className="text-gray-500 dark:text-gray-400 text-lg leading-relaxed max-w-xl mx-auto lg:mx-0 font-medium">
                    {step.desc[lang]}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Payment Methods Breakdown */}
        <div className="mt-32 pt-20 border-t dark:border-gray-800">
           <div className="text-center mb-16 space-y-4">
              <h2 className="text-4xl font-black text-blue-900 dark:text-white">تفاصيل طرق الشحن المتاحة</h2>
              <p className="text-gray-500 dark:text-gray-400 font-bold">نوفر لك أسهل الوسائل لتفعيل حسابك في ثوانٍ</p>
           </div>

           <div className="grid md:grid-cols-3 gap-8">
              <div className="bg-white dark:bg-gray-900 p-8 rounded-[2.5rem] border border-gray-100 dark:border-gray-800 shadow-sm hover:shadow-xl transition-all">
                 <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 text-red-600 rounded-2xl flex items-center justify-center mb-6">
                    <Smartphone size={32} />
                 </div>
                 <h4 className="text-xl font-black text-blue-900 dark:text-white mb-4">فودافون كاش</h4>
                 <ul className="text-sm text-gray-500 dark:text-gray-400 space-y-3 font-bold">
                    <li className="flex items-start gap-2">• التحويل للرقم المخصص</li>
                    <li className="flex items-start gap-2">• رفع "سكرين شوت" أو كتابة رقمك</li>
                    <li className="flex items-start gap-2">• تفعيل الحساب فور مراجعة التحويل</li>
                 </ul>
              </div>

              <div className="bg-white dark:bg-gray-900 p-8 rounded-[2.5rem] border border-gray-100 dark:border-gray-800 shadow-sm hover:shadow-xl transition-all">
                 <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900/30 text-blue-600 rounded-2xl flex items-center justify-center mb-6">
                    <CreditCard size={32} />
                 </div>
                 <h4 className="text-xl font-black text-blue-900 dark:text-white mb-4">فيزا / ماستركارد</h4>
                 <ul className="text-sm text-gray-500 dark:text-gray-400 space-y-3 font-bold">
                    <li className="flex items-start gap-2">• إدخال بيانات البطاقة بأمان تام</li>
                    <li className="flex items-start gap-2">• تفعيل فوري ومباشر للمحتوى</li>
                    <li className="flex items-start gap-2">• نظام مشفر (SSL) لحماية بياناتك</li>
                 </ul>
              </div>

              <div className="bg-white dark:bg-gray-900 p-8 rounded-[2.5rem] border border-gray-100 dark:border-gray-800 shadow-sm hover:shadow-xl transition-all">
                 <div className="w-16 h-16 bg-green-100 dark:bg-green-900/30 text-green-600 rounded-2xl flex items-center justify-center mb-6">
                    <ShieldCheck size={32} />
                 </div>
                 <h4 className="text-xl font-black text-blue-900 dark:text-white mb-4">فوري (Fawry)</h4>
                 <ul className="text-sm text-gray-500 dark:text-gray-400 space-y-3 font-bold">
                    <li className="flex items-start gap-2">• الحصول على كود دفع "فوري"</li>
                    <li className="flex items-start gap-2">• التوجه لأقرب ماكينة دفع</li>
                    <li className="flex items-start gap-2">• تفعيل الحساب تلقائياً بعد الدفع</li>
                 </ul>
              </div>
           </div>
        </div>

        {/* Call to Action */}
        <div className="mt-32 p-12 bg-blue-50 dark:bg-blue-900/20 rounded-[3rem] border border-blue-100 dark:border-blue-900/50 text-center space-y-8">
           <h2 className="text-3xl font-black text-blue-900 dark:text-white">
              {lang === 'ar' ? 'هل أنت مستعد للبدء؟' : 'Ready to Start?'}
           </h2>
           <p className="text-gray-600 dark:text-gray-300 max-w-2xl mx-auto text-lg font-bold">
              {lang === 'ar' 
                ? 'انضم الآن لطلابنا الذين حققوا حلمهم في دخول كلية الهندسة عبر منصتنا.' 
                : 'Join our students who achieved their dream of entering Engineering school via our platform.'}
           </p>
           <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <button 
                onClick={() => navigate('/auth')}
                className="w-full sm:w-auto px-12 py-5 bg-blue-700 text-white rounded-2xl font-black text-xl hover:bg-blue-800 shadow-xl shadow-blue-200 dark:shadow-none transition-all active:scale-95"
              >
                {lang === 'ar' ? 'سجل الآن' : 'Register Now'}
              </button>
              <button 
                onClick={() => navigate('/')}
                className="w-full sm:w-auto px-12 py-5 bg-white dark:bg-gray-800 text-blue-700 dark:text-blue-400 border-2 border-blue-200 dark:border-blue-900/50 rounded-2xl font-black text-xl hover:bg-blue-50 dark:hover:bg-gray-700 transition-all active:scale-95"
              >
                {lang === 'ar' ? 'العودة للرئيسية' : 'Back Home'}
              </button>
           </div>
        </div>
      </section>
    </div>
  );
};

export default HowTo;
