
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertCircle, ArrowRight, Construction, Search } from 'lucide-react';
import { Language } from '../types';

interface UnavailableContentProps {
  t: any;
  lang: Language;
}

const UnavailableContent: React.FC<UnavailableContentProps> = ({ t, lang }) => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('all');
  const isRTL = lang === 'ar';

  const navItems = [
    { id: 'all', ar: 'الكل', en: 'All' },
    { id: 'algebra', ar: 'الجبر', en: 'Algebra' },
    { id: 'geometry', ar: 'الهندسة الفراغية', en: 'Solid Geometry' },
    { id: 'diff', ar: 'قواعد الاشتقاق', en: 'Rules of Differentiation' },
    { id: 'int', ar: 'التكامل وتطبيقاته', en: 'Integration' },
  ];

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 pb-20 transition-colors duration-300">
      {/* Top Navigation Bar */}
      <div className="bg-white dark:bg-gray-900 border-b dark:border-gray-800 sticky top-20 z-40 shadow-sm overflow-x-auto no-scrollbar">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 md:gap-8 h-16 whitespace-nowrap">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`px-4 py-2 rounded-xl font-bold text-sm transition-all flex items-center gap-2 h-10 ${
                  activeTab === item.id 
                    ? 'bg-blue-600 text-white shadow-lg' 
                    : 'text-gray-500 dark:text-gray-400 hover:bg-blue-50 dark:hover:bg-blue-900/30 hover:text-blue-600'
                }`}
              >
                {lang === 'ar' ? item.ar : item.en}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="flex items-center justify-center pt-24 px-6">
        <div className="max-w-md w-full text-center space-y-8 animate-in fade-in zoom-in duration-500">
          <div className="relative inline-block">
            <div className="w-32 h-32 bg-yellow-100 dark:bg-yellow-900/20 rounded-full flex items-center justify-center text-yellow-600 dark:text-yellow-500 mx-auto">
              <Construction size={64} />
            </div>
            <div className="absolute -top-2 -right-2 w-10 h-10 bg-red-500 rounded-full flex items-center justify-center text-white border-4 border-white dark:border-gray-900">
              <AlertCircle size={20} />
            </div>
          </div>

          <div className="space-y-4">
            <h2 className="text-3xl font-black text-blue-900 dark:text-white">
              {lang === 'ar' ? 'المحتوى غير متوفر حالياً' : 'Content Currently Unavailable'}
            </h2>
            <div className="inline-block px-4 py-1.5 bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 rounded-full text-xs font-bold mb-2">
               {navItems.find(i => i.id === activeTab)?.[lang === 'ar' ? 'ar' : 'en']}
            </div>
            <p className="text-gray-500 dark:text-gray-400 text-lg leading-relaxed font-medium">
              {lang === 'ar' 
                ? 'نحن نعمل حالياً على تجهيز هذا المحتوى بأعلى جودة ممكنة. سيتم إضافته قريباً جداً!' 
                : 'We are currently preparing this content with the highest quality. It will be added very soon!'}
            </p>
          </div>

          <div className="pt-6">
            <button 
              onClick={() => navigate(-1)}
              className="inline-flex items-center gap-2 bg-blue-700 text-white px-8 py-4 rounded-2xl font-bold hover:bg-blue-800 transition-all shadow-xl shadow-blue-200 dark:shadow-none group"
            >
              {isRTL && <ArrowRight className="rotate-0 group-hover:translate-x-1 transition-transform" size={20} />}
              <span>{lang === 'ar' ? 'العودة للخلف' : 'Go Back'}</span>
              {!isRTL && <ArrowRight className="rotate-180 group-hover:-translate-x-1 transition-transform" size={20} />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UnavailableContent;
