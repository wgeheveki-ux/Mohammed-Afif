
import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
// Senior Engineer Fix: Removed non-existent TallyMarks and other unused icons from lucide-react to resolve the import error.
import { 
  ChevronLeft, Sparkles, UserPlus, Compass, 
  SquareFunction, Box, Activity, Infinity
} from 'lucide-react';
import { Language, User } from '../types';

interface HomeProps {
  t: any;
  lang: Language;
  user: User | null;
}

const Home: React.FC<HomeProps> = ({ t, lang, user }) => {
  const isRTL = lang === Language.AR;
  const navigate = useNavigate();
  const [counts, setCounts] = useState({ courses: 0, sections: 0 });

  const loadData = () => {
    const lessons = JSON.parse(localStorage.getItem('afifi_lessons') || '[]');
    const sections = JSON.parse(localStorage.getItem('afifi_sections') || '[]');
    setCounts({ courses: lessons.length, sections: sections.length });
  };

  useEffect(() => {
    loadData();
    window.addEventListener('storage', loadData);
    window.addEventListener('afifi_data_updated', loadData);
    
    return () => {
      window.removeEventListener('storage', loadData);
      window.removeEventListener('afifi_data_updated', loadData);
    };
  }, []);

  const handleSubjectClick = (subjectId: string) => {
    navigate('/lessons');
  };

  // تعريف الكروت بأيقونات "قوية" وعلامات مائية (Watermarks)
  const subjectCards = [
    { 
      id: 'algebra', 
      title: t.algebra, 
      color: 'from-blue-700 to-blue-900', 
      icon: <SquareFunction size={42} strokeWidth={2.5} />,
      watermark: 'Σ',
      shape: 'polygon(50% 0%, 100% 38%, 82% 100%, 18% 100%, 0% 38%)',
      pattern: "bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"
    },
    { 
      id: 'geometry', 
      title: t.geometry, 
      color: 'from-indigo-700 to-indigo-900', 
      icon: <Box size={42} strokeWidth={2.5} />,
      watermark: 'Δ',
      shape: 'polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)',
      pattern: "bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"
    },
    { 
      id: 'calculus', 
      title: t.calculus, 
      color: 'from-purple-700 to-purple-900', 
      icon: <Activity size={42} strokeWidth={2.5} />,
      watermark: 'd/dx',
      shape: 'circle(50% at 50% 50%)',
      pattern: "bg-[url('https://www.transparenttextures.com/patterns/circuit-board.png')]"
    },
    { 
      id: 'applied', 
      title: t.applied, 
      color: 'from-rose-700 to-rose-900', 
      icon: <Infinity size={42} strokeWidth={2.5} />,
      watermark: '∫',
      shape: 'polygon(50% 0%, 0% 100%, 100% 100%)',
      pattern: "bg-[url('https://www.transparenttextures.com/patterns/grid-me.png')]"
    },
  ];

  const floatingMathSymbols = [
    { char: '∫', top: '10%', left: '5%', size: 'text-8xl', delay: '0s' },
    { char: 'Σ', top: '20%', left: '90%', size: 'text-9xl', delay: '3s' },
    { char: '√', top: '70%', left: '10%', size: 'text-7xl', delay: '5s' },
    { char: 'λ', top: '80%', left: '85%', size: 'text-8xl', delay: '2s' },
  ];

  return (
    <div className="overflow-hidden font-cairo bg-white dark:bg-gray-950 transition-colors duration-500">
      {/* Hero Section */}
      <section className="relative pt-24 pb-40 overflow-hidden">
        {/* Background Decorative Symbols */}
        <div className="absolute inset-0 pointer-events-none select-none overflow-hidden opacity-10 dark:opacity-20">
          {floatingMathSymbols.map((sym, i) => (
            <div key={i} className={`absolute font-serif font-black text-blue-900 dark:text-blue-100 ${sym.size} animate-math blur-[1px]`} style={{ top: sym.top, left: sym.left, animationDelay: sym.delay }}>
              {sym.char}
            </div>
          ))}
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
           <div className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-400 font-black text-sm animate-bounce shadow-sm mb-12 border border-amber-100 dark:border-amber-800">
              <Sparkles size={18} />
              <span>الإمبراطورية رقم #1 لطلاب المعادلة في مصر</span>
            </div>
            
            <h1 className="text-6xl md:text-9xl font-black text-blue-900 dark:text-white leading-[0.9] mb-12 tracking-tighter">
              {lang === 'ar' ? (
                <>
                  <span className="block text-blue-600 drop-shadow-sm">الأسطورة</span> 
                  في عالم الرياضيات
                </>
              ) : (
                <>
                  The <span className="text-blue-600">Legend</span> <br/> of Mathematics
                </>
              )}
            </h1>
            
            <p className="text-xl md:text-3xl text-gray-500 dark:text-gray-300 leading-relaxed max-w-4xl mx-auto font-bold mb-20 px-4">
              {lang === 'ar' 
                ? "مستقبلك يبدأ من هنا.. نحن لا نشرح المنهج، نحن نبني عقول المهندسين. انضم لإمبراطورية م/ محمد عفيفي واضمن مكانك في القمة." 
                : "Your future starts here. We build engineering minds. Join the Empire of Eng. Mohamed Afifi and secure your place at the top."}
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-8">
              <Link to="/lessons" className="w-full sm:w-auto px-20 py-7 bg-blue-700 text-white rounded-[2.5rem] font-black text-2xl hover:bg-blue-800 shadow-[0_25px_60px_rgba(30,58,138,0.4)] hover:-translate-y-2 transition-all flex items-center justify-center gap-4 active:scale-95 group overflow-hidden relative">
                <div className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
                <Compass className="group-hover:rotate-180 transition-transform duration-700 text-amber-300 relative z-10" size={36} />
                <span className="relative z-10">استكشاف المسارات</span>
              </Link>
              <Link to="/how-to" className="w-full sm:w-auto px-20 py-7 bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-200 rounded-[2.5rem] font-black text-2xl hover:bg-gray-200 dark:hover:bg-gray-700 transition-all text-center border-2 border-transparent hover:border-blue-400 flex items-center justify-center gap-4 group">
                <UserPlus className="group-hover:scale-125 transition-transform text-blue-600" size={32} />
                طريقة التسجيل
              </Link>
            </div>
        </div>
      </section>

      {/* Stats Section - REPLACED WITH STRONGER EMPIRE LABELS */}
      <section className="py-24 bg-blue-950 text-white overflow-hidden relative">
         <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20"></div>
         <div className="max-w-7xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-12 text-center relative z-10">
            {[
              { val: '+5000', label: 'ساعة من نقل الأسرار الهندسية' },
              { val: '+12000', label: 'لغز امتحاني تم فكه بنجاح' },
              { val: '+3500', label: 'مهندس صُنع في الإمبراطورية' },
              { val: '100%', label: 'السيطرة الكاملة على المنهج' }
            ].map((stat, i) => (
              <div key={i} className="space-y-4 group">
                 <div className="text-5xl md:text-7xl font-black text-blue-400 group-hover:scale-110 transition-transform duration-500 drop-shadow-[0_0_25px_rgba(96,165,250,0.5)] tracking-tighter">{stat.val}</div>
                 <div className="text-xs md:text-sm font-black text-blue-200/80 uppercase tracking-[0.15em] border-t border-blue-800 pt-4 mx-auto max-w-[80%]">{stat.label}</div>
              </div>
            ))}
         </div>
      </section>

      {/* Empire Pillars */}
      <section className="py-40 bg-gray-50 dark:bg-gray-900 transition-colors duration-300 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-end justify-between mb-28 gap-10">
            <div className="space-y-6">
              <div className="inline-block px-4 py-1.5 bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-400 rounded-lg text-sm font-black tracking-widest uppercase">The Pillars</div>
              <h2 className="text-6xl font-black text-blue-900 dark:text-white tracking-tighter">أركان الإمبراطورية</h2>
              <p className="text-gray-500 dark:text-gray-400 font-bold text-2xl max-w-2xl leading-relaxed">هنا تُصنع العقول الهندسية. مناهج مكثفة، أيقونات قوية، وعلامات مائية تعكس دقة الرياضيات.</p>
            </div>
            <Link to="/lessons" className="px-10 py-5 bg-white dark:bg-gray-800 text-blue-700 dark:text-blue-400 rounded-2xl font-black flex items-center gap-3 hover:gap-6 transition-all shadow-xl shadow-blue-900/5">
               تصفح المنهج كاملاً <ChevronLeft />
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
            {subjectCards.map(item => (
              <button 
                key={item.id} 
                onClick={() => handleSubjectClick(item.id)} 
                className="group p-2 bg-white dark:bg-gray-900 rounded-[4rem] shadow-sm border border-gray-100 dark:border-gray-800 transition-all hover:shadow-[0_50px_100px_-20px_rgba(30,58,138,0.25)] hover:-translate-y-6 text-start w-full relative overflow-hidden"
              >
                <div className="p-12 relative z-10">
                  {/* Icon Container with Custom Geometric Shape Clip */}
                  <div className={`w-28 h-28 bg-gradient-to-br ${item.color} rounded-[2.5rem] flex items-center justify-center text-white mb-12 shadow-2xl group-hover:rotate-[20deg] group-hover:scale-125 transition-all duration-700 relative overflow-hidden ring-4 ring-white dark:ring-gray-700`}>
                    
                    {/* Strong Math Watermark */}
                    <div className="absolute inset-0 flex items-center justify-center opacity-20 pointer-events-none group-hover:opacity-40 transition-opacity duration-500 -translate-x-1 -translate-y-1">
                       <span className="text-8xl font-serif font-black select-none italic text-white/50">{item.watermark}</span>
                    </div>

                    {/* Geometric Pattern Overlay */}
                    <div className={`absolute inset-0 opacity-25 mix-blend-overlay ${item.pattern}`}></div>
                    
                    {/* Main Icon */}
                    <div className="relative z-10 drop-shadow-[0_5px_15px_rgba(0,0,0,0.3)]">
                      {item.icon}
                    </div>
                  </div>
                  
                  <h3 className="text-4xl font-black text-blue-900 dark:text-white mb-6 group-hover:text-blue-600 transition-colors leading-tight">{item.title}</h3>
                  
                  <div className="flex items-center justify-between mt-auto">
                     <div className="flex flex-col">
                        <span className="text-[10px] text-gray-400 font-black uppercase tracking-[0.2em] mb-1">Status</span>
                        <p className="text-sm text-blue-600 dark:text-blue-400 font-black">متاح الآن</p>
                     </div>
                     <div className="w-14 h-14 rounded-3xl bg-blue-50 dark:bg-blue-900/30 flex items-center justify-center text-blue-700 dark:text-blue-300 opacity-0 group-hover:opacity-100 group-hover:translate-x-0 translate-x-10 transition-all duration-700">
                        <ChevronLeft size={28} strokeWidth={3}/>
                     </div>
                  </div>
                </div>
                
                {/* Background "Strong" Watermark Decoration for the whole card */}
                <div className="absolute -bottom-10 -right-10 text-[180px] font-black text-gray-100 dark:text-gray-700/20 leading-none select-none opacity-0 group-hover:opacity-100 transition-all duration-1000 rotate-[-15deg]">
                   {item.watermark}
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Dynamic CTA */}
      <section className="py-40 bg-blue-900 text-white relative overflow-hidden">
         <div className="absolute top-0 right-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/diagonal-lines.png')] opacity-10"></div>
         <div className="max-w-5xl mx-auto px-4 text-center relative z-10 space-y-16">
            <h2 className="text-6xl md:text-8xl font-black leading-[0.85] tracking-tighter">هل تريد أن تكون بطل القصة القادم؟</h2>
            <p className="text-2xl text-blue-100 font-bold max-w-3xl mx-auto leading-relaxed opacity-80">أكثر من 3500 طالب عبروا من خلالنا إلى حلمهم في الهندسة. مقعدك في مدرج "هندسة" بانتظار قرارك اليوم.</p>
            <div className="pt-8">
               <Link to="/auth" className="inline-block px-24 py-8 bg-white text-blue-900 rounded-[3rem] font-black text-3xl hover:scale-105 transition-all shadow-[0_30px_70px_rgba(0,0,0,0.4)] active:scale-95">سجل في إحصائيات الناجحين</Link>
            </div>
         </div>
      </section>
    </div>
  );
};

export default Home;
