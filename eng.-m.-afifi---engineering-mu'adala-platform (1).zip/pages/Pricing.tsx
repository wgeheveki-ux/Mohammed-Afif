
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Check, Shield, Zap, CreditCard, Smartphone, Globe, 
  X, ChevronLeft, CreditCard as CardIcon, Wallet, Info, Loader2, Copy
} from 'lucide-react';
import { Language } from '../types';

interface PricingProps {
  t: any;
  lang: Language;
}

interface Plan {
  id: string;
  name: Record<string, string>;
  price: string;
  period: Record<string, string>;
  desc: Record<string, string>;
  features: Record<string, string>[];
  button: Record<string, string>;
  popular: boolean;
}

const Pricing: React.FC<PricingProps> = ({ t, lang }) => {
  const navigate = useNavigate();
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'wallet' | 'fawry'>('card');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [copied, setCopied] = useState(false);

  const plans: Plan[] = [
    {
      id: 'monthly',
      name: { ar: 'الباقة الشهرية', en: 'Monthly Plan' },
      price: '150',
      period: { ar: 'شهرياً', en: '/ month' },
      desc: { ar: 'مثالية لتجربة المنصة واستكشاف المحتوى.', en: 'Ideal for trying out the platform and exploring content.' },
      features: [
        { ar: 'وصول كامل لجميع الدروس', en: 'Full access to all lessons' },
        { ar: 'تحميل جميع ملفات PDF', en: 'Download all PDF materials' },
        { ar: 'اختبارات تقييمية غير محدودة', en: 'Unlimited assessment quizzes' },
        { ar: 'دعم فني عبر واتساب', en: 'WhatsApp technical support' },
      ],
      button: { ar: 'اشترك الآن', en: 'Subscribe Now' },
      popular: false,
    },
    {
      id: 'annual',
      name: { ar: 'الباقة السنوية', en: 'Annual Plan' },
      price: '1200',
      period: { ar: 'سنوياً', en: '/ year' },
      desc: { ar: 'توفير 33% - الخيار الأفضل لطلاب المعادلة.', en: 'Save 33% - Best choice for Muadala students.' },
      features: [
        { ar: 'كل ميزات الباقة الشهرية', en: 'All monthly plan features' },
        { ar: 'مساعد الذكي AI غير محدود', en: 'Unlimited AI Assistant usage' },
        { ar: 'شهادات إتمام معتمدة', en: 'Certified completion certificates' },
        { ar: 'أولوية في الرد على الأسئلة', en: 'Priority in answering questions' },
        { ar: 'توفير مالي كبير', en: 'Significant cost savings' },
      ],
      button: { ar: 'اشترك الآن', en: 'Subscribe Now' },
      popular: true,
    },
    {
      id: 'final',
      name: { ar: 'باقة المراجعة النهائية', en: 'Final Review' },
      price: '500',
      period: { ar: 'لمرة واحدة', en: 'One time' },
      desc: { ar: 'مخصصة للمراجعات والامتحانات النهائية.', en: 'Dedicated for final reviews and exams.' },
      features: [
        { ar: 'بنك أسئلة الامتحانات السابقة', en: 'Past exams question bank' },
        { ar: 'فيديوهات المراجعة المكثفة', en: 'Intensive review videos' },
        { ar: 'نماذج امتحانات المحاكاة', en: 'Mock simulation exams' },
        { ar: 'توقعات ليلة الامتحان', en: 'Exam night predictions' },
      ],
      button: { ar: 'اشتري الآن', en: 'Buy Now' },
      popular: false,
    },
  ];

  const handleSubscribe = (plan: Plan) => {
    setSelectedPlan(plan);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText('+201100448213');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const processPayment = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setIsSuccess(true);
    }, 2500);
  };

  return (
    <div className="bg-gray-50 dark:bg-gray-950 min-h-screen pb-20 transition-colors duration-300">
      <section className="bg-blue-900 dark:bg-gray-900 py-24 text-center text-white">
        <div className="max-w-4xl mx-auto px-4">
          <h1 className="text-4xl md:text-6xl font-black mb-6">خطط الاشتراك</h1>
          <p className="text-xl text-blue-100 dark:text-gray-400">اختر الباقة المناسبة لك وابدأ رحلة نجاحك في المعادلة اليوم</p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-16">
        <div className="grid md:grid-cols-3 gap-8">
          {plans.map((plan) => (
            <div 
              key={plan.id} 
              className={`relative bg-white dark:bg-gray-900 rounded-[2.5rem] p-10 shadow-xl border transition-all hover:-translate-y-2 ${
                plan.popular 
                  ? 'border-blue-500 ring-4 ring-blue-500/10' 
                  : 'border-gray-100 dark:border-gray-800'
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-blue-600 text-white px-6 py-1.5 rounded-full text-sm font-bold shadow-lg">
                  الأكثر شيوعاً
                </div>
              )}

              <div className="mb-8">
                <h3 className="text-2xl font-black text-blue-900 dark:text-white mb-4">{plan.name[lang]}</h3>
                <div className="flex items-baseline gap-1">
                  <span className="text-4xl font-black text-gray-900 dark:text-white">{plan.price}</span>
                  <span className="text-gray-500 dark:text-gray-400 font-bold">{plan.period[lang]}</span>
                </div>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-4 leading-relaxed">{plan.desc[lang]}</p>
              </div>

              <ul className="space-y-4 mb-10">
                {plan.features.map((feature, fIdx) => (
                  <li key={fIdx} className="flex items-start gap-3">
                    <div className="w-5 h-5 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center text-green-600 dark:text-green-400 mt-1 flex-shrink-0">
                      <Check size={12} />
                    </div>
                    <span className="text-sm text-gray-600 dark:text-gray-300 font-medium">{feature[lang]}</span>
                  </li>
                ))}
              </ul>

              <button 
                onClick={() => handleSubscribe(plan)}
                className={`w-full py-4 rounded-2xl font-black text-lg transition-all shadow-lg ${
                plan.popular 
                  ? 'bg-blue-700 text-white hover:bg-blue-800 shadow-blue-200 dark:shadow-none' 
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}>
                {plan.button[lang]}
              </button>
            </div>
          ))}
        </div>

        <div className="mt-20 text-center space-y-8">
          <div className="inline-flex items-center gap-2 px-6 py-2 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400 rounded-full text-sm font-bold">
            <Shield size={18} />
            بوابة دفع آمنة ومشفرة 100%
          </div>
          
          <div className="flex flex-wrap justify-center items-center gap-12 grayscale opacity-50 hover:grayscale-0 hover:opacity-100 transition-all duration-500">
             <div className="flex flex-col items-center gap-2">
                <CreditCard size={40} className="text-blue-900 dark:text-white" />
                <span className="text-xs font-bold text-gray-400">Visa / MasterCard</span>
             </div>
             <div className="flex flex-col items-center gap-2">
                <Smartphone size={40} className="text-blue-900 dark:text-white" />
                <span className="text-xs font-bold text-gray-400">Vodafone Cash</span>
             </div>
             <div className="flex flex-col items-center gap-2">
                <Globe size={40} className="text-blue-900 dark:text-white" />
                <span className="text-xs font-bold text-gray-400">Fawry Pay</span>
             </div>
          </div>
        </div>
      </div>

      {selectedPlan && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-blue-900/40 backdrop-blur-sm animate-in fade-in duration-300">
          <div className="bg-white dark:bg-gray-900 w-full max-w-2xl rounded-[3rem] shadow-2xl overflow-hidden flex flex-col md:flex-row relative animate-in zoom-in slide-in-from-bottom-4 duration-300">
            <button 
              onClick={() => { setSelectedPlan(null); setIsSuccess(false); }}
              className="absolute top-6 right-6 p-2 bg-gray-100 dark:bg-gray-800 text-gray-500 hover:text-red-500 rounded-full transition-colors z-10"
            >
              <X size={20} />
            </button>

            {isSuccess ? (
              <div className="w-full p-12 text-center space-y-6">
                <div className="w-24 h-24 bg-green-100 dark:bg-green-900/30 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Check size={48} strokeWidth={3} />
                </div>
                <h2 className="text-3xl font-black text-blue-900 dark:text-white">تم الاشتراك بنجاح!</h2>
                <p className="text-gray-500 dark:text-gray-400">تهانينا، تم تفعيل اشتراكك في {selectedPlan.name[lang]}. يمكنك الآن البدء في متابعة الدروس فوراً.</p>
                <button 
                  onClick={() => navigate('/lessons')}
                  className="w-full py-4 bg-blue-700 text-white rounded-2xl font-black text-lg hover:bg-blue-800 transition-all"
                >
                  ابدأ التعلم الآن
                </button>
              </div>
            ) : (
              <>
                <div className="w-full md:w-72 bg-blue-50 dark:bg-blue-900/20 p-8 flex flex-col justify-between">
                  <div>
                    <h4 className="text-xs font-black text-blue-600 dark:text-blue-400 uppercase tracking-widest mb-6">ملخص الطلب</h4>
                    <div className="space-y-4">
                      <div>
                        <p className="text-sm text-gray-500 dark:text-gray-400 font-bold">الباقة المختارة</p>
                        <p className="text-lg font-black text-blue-900 dark:text-white leading-tight">{selectedPlan.name[lang]}</p>
                      </div>
                      <div className="pt-4 border-t border-blue-100 dark:border-blue-900/50">
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-sm font-bold text-gray-500">السعر</span>
                          <span className="font-bold text-blue-900 dark:text-white">{selectedPlan.price} EGP</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-bold text-gray-500">الضريبة</span>
                          <span className="font-bold text-blue-900 dark:text-white">0.00 EGP</span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="pt-6 mt-6 border-t border-blue-200 dark:border-blue-900/50 flex justify-between items-center">
                    <span className="text-lg font-black text-blue-900 dark:text-white">الإجمالي</span>
                    <span className="text-2xl font-black text-blue-700 dark:text-blue-400">{selectedPlan.price} EGP</span>
                  </div>
                </div>

                <div className="flex-1 p-8 md:p-12">
                  <h3 className="text-2xl font-black text-blue-900 dark:text-white mb-8">اختر وسيلة الدفع</h3>
                  
                  <div className="flex p-1 bg-gray-100 dark:bg-gray-800 rounded-2xl mb-8">
                    <button 
                      onClick={() => setPaymentMethod('card')}
                      className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-bold text-sm transition-all ${paymentMethod === 'card' ? 'bg-white dark:bg-gray-700 shadow-md text-blue-700 dark:text-white' : 'text-gray-500 hover:text-gray-700'}`}
                    >
                      <CardIcon size={18} />
                      <span className="hidden sm:inline">بطاقة بنكية</span>
                    </button>
                    <button 
                      onClick={() => setPaymentMethod('wallet')}
                      className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-bold text-sm transition-all ${paymentMethod === 'wallet' ? 'bg-white dark:bg-gray-700 shadow-md text-blue-700 dark:text-white' : 'text-gray-500 hover:text-gray-700'}`}
                    >
                      <Wallet size={18} />
                      <span className="hidden sm:inline">محفظة</span>
                    </button>
                    <button 
                      onClick={() => setPaymentMethod('fawry')}
                      className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-bold text-sm transition-all ${paymentMethod === 'fawry' ? 'bg-white dark:bg-gray-700 shadow-md text-blue-700 dark:text-white' : 'text-gray-500 hover:text-gray-700'}`}
                    >
                      <Globe size={18} />
                      <span className="hidden sm:inline">فوري</span>
                    </button>
                  </div>

                  <div className="space-y-6">
                    {paymentMethod === 'card' && (
                      <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
                        <div className="space-y-2">
                          <label className="text-xs font-black text-gray-500 uppercase">رقم البطاقة</label>
                          <div className="relative">
                            <input type="text" placeholder="**** **** **** ****" className="w-full bg-gray-50 dark:bg-gray-800 border-none ring-1 ring-gray-200 dark:ring-gray-700 rounded-xl py-3 px-4 font-mono focus:ring-2 focus:ring-blue-500" />
                            <CardIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <label className="text-xs font-black text-gray-500 uppercase">تاريخ الانتهاء</label>
                            <input type="text" placeholder="MM/YY" className="w-full bg-gray-50 dark:bg-gray-800 border-none ring-1 ring-gray-200 dark:ring-gray-700 rounded-xl py-3 px-4 font-mono focus:ring-2 focus:ring-blue-500" />
                          </div>
                          <div className="space-y-2">
                            <label className="text-xs font-black text-gray-500 uppercase">CVV</label>
                            <input type="text" placeholder="***" className="w-full bg-gray-50 dark:bg-gray-800 border-none ring-1 ring-gray-200 dark:ring-gray-700 rounded-xl py-3 px-4 font-mono focus:ring-2 focus:ring-blue-500" />
                          </div>
                        </div>
                      </div>
                    )}

                    {paymentMethod === 'wallet' && (
                      <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                        <div className="p-5 bg-green-50 dark:bg-green-900/20 border border-green-100 dark:border-green-900/50 rounded-[2rem] space-y-4">
                           <div className="flex items-center gap-3 text-green-700 dark:text-green-400 font-black">
                              <Info size={20} />
                              <span className="text-sm">تعليمات الدفع عبر فودافون كاش</span>
                           </div>
                           <p className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed font-bold">
                              قم بتحويل المبلغ المطلوب ({selectedPlan.price} EGP) إلى الرقم التالي، ثم أدخل رقمك الذي قمت بالتحويل منه بالأسفل.
                           </p>
                           <div className="bg-white dark:bg-gray-800 p-4 rounded-2xl flex items-center justify-between border border-green-200 dark:border-green-800 group">
                              <span className="text-xl font-black text-blue-900 dark:text-white tracking-wider">+20 11 00448213</span>
                              <button 
                                onClick={copyToClipboard}
                                className={`p-2 rounded-xl transition-all ${copied ? 'bg-green-500 text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-500 hover:text-blue-600'}`}
                              >
                                {copied ? <Check size={18} /> : <Copy size={18} />}
                              </button>
                           </div>
                        </div>

                        <div className="space-y-2">
                          <label className="text-xs font-black text-gray-500 uppercase">رقم الموبايل (الذي قمت بالتحويل منه)</label>
                          <input type="tel" placeholder="01xxxxxxxxx" className="w-full bg-gray-50 dark:bg-gray-800 border-none ring-1 ring-gray-200 dark:ring-gray-700 rounded-xl py-3 px-4 font-bold focus:ring-2 focus:ring-blue-500" />
                        </div>
                      </div>
                    )}

                    {paymentMethod === 'fawry' && (
                      <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
                        <div className="p-4 bg-blue-50 dark:bg-blue-900/30 rounded-2xl border border-blue-100 dark:border-blue-800 flex items-start gap-3">
                           <Info className="text-blue-600 flex-shrink-0" size={20} />
                           <p className="text-xs text-blue-900 dark:text-blue-300 leading-relaxed font-bold">عند الضغط على "تأكيد"، ستحصل على كود دفع صالح لمدة 24 ساعة للتوجه لأي ماكينة فوري.</p>
                        </div>
                      </div>
                    )}

                    <button 
                      onClick={processPayment}
                      disabled={isProcessing}
                      className="w-full py-5 bg-blue-700 text-white rounded-2xl font-black text-lg hover:bg-blue-800 shadow-xl shadow-blue-100 disabled:opacity-70 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-3"
                    >
                      {isProcessing ? (
                        <>
                          <Loader2 className="animate-spin" />
                          جاري المعالجة...
                        </>
                      ) : (
                        <>
                          تأكيد الدفع والاشتراك
                        </>
                      )}
                    </button>

                    <div className="flex items-center justify-center gap-2 text-[10px] text-gray-400 font-bold uppercase tracking-widest">
                       <Shield size={14} />
                       <span>Powered by AfifiPay Secure Gateway</span>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default Pricing;
