
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Clock, PlayCircle, BookOpen, Lock } from 'lucide-react';
import { Language, Subject, Difficulty, User, Lesson } from '../types';
import { MOCK_LESSONS } from '../constants';

interface LessonsProps {
  t: any;
  lang: Language;
  user: User | null;
}

const Lessons: React.FC<LessonsProps> = ({ t, lang, user }) => {
  const navigate = useNavigate();
  const [activeSubject, setActiveSubject] = useState<string | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [sections, setSections] = useState<string[]>([]);

  const loadData = () => {
    const savedLessons = localStorage.getItem('afifi_lessons');
    const savedSections = localStorage.getItem('afifi_sections');
    
    if (savedLessons) {
      setLessons(JSON.parse(savedLessons));
    } else {
      setLessons(MOCK_LESSONS);
    }
    
    if (savedSections) {
      setSections(JSON.parse(savedSections));
    } else {
      setSections(['الجبر', 'الهندسة الفراغية', 'التفاضل', 'التكامل']);
    }
  };

  useEffect(() => {
    loadData();
    window.addEventListener('storage', loadData);
    window.addEventListener('afifi_data_updated', loadData);
    
    return () => {
      window.removeEventListener('storage', loadData);
      window.removeEventListener('afifi_data_updated', loadData);
    };
  }, []);

  const filteredLessons = lessons.filter(lesson => {
    const matchesSubject = activeSubject === 'all' || lesson.subject === activeSubject;
    const matchesSearch = lesson.title[lang].toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSubject && matchesSearch;
  });

  const handleLessonClick = (lessonId: string) => {
    navigate(`/lesson/${lessonId}`);
  };

  return (
    <div className="bg-gray-50 dark:bg-gray-950 min-h-screen py-12 transition-colors duration-300 font-cairo">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
          <div>
            <h1 className="text-3xl font-black text-blue-900 dark:text-white mb-2">{t.courses}</h1>
            <p className="text-gray-500 dark:text-gray-400 font-bold">تصفح أحدث محاضرات المهندس محمد عفيفي</p>
          </div>
          
          <div className="flex items-center gap-4 bg-white dark:bg-gray-900 p-2 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800 flex-1 max-w-md">
            <Search className="text-gray-400 mr-2" size={20} />
            <input 
              type="text" 
              placeholder="بحث عن محاضرة..." 
              className="bg-transparent border-none focus:ring-0 flex-1 py-2 text-sm dark:text-white font-bold"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        <div className="flex flex-wrap gap-4 mb-12">
          <div className="flex p-1.5 bg-white dark:bg-gray-900 rounded-2xl shadow-sm border border-gray-100 dark:border-gray-800 overflow-x-auto no-scrollbar max-w-full">
            <button
              onClick={() => setActiveSubject('all')}
              className={`px-6 py-2.5 rounded-xl font-black text-sm transition-all whitespace-nowrap ${
                activeSubject === 'all' ? 'bg-blue-600 text-white shadow-lg' : 'text-gray-500 dark:text-gray-400 hover:bg-blue-50'
              }`}
            >
              الكل
            </button>
            {sections.map((s) => (
              <button
                key={s}
                onClick={() => setActiveSubject(s)}
                className={`px-6 py-2.5 rounded-xl font-black text-sm transition-all whitespace-nowrap ${
                  activeSubject === s ? 'bg-blue-600 text-white shadow-lg' : 'text-gray-500 dark:text-gray-400 hover:bg-blue-50'
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredLessons.map(lesson => (
            <button 
              key={lesson.id} 
              onClick={() => handleLessonClick(lesson.id)}
              className="group bg-white dark:bg-gray-900 rounded-[2.5rem] shadow-sm border border-gray-100 dark:border-gray-800 overflow-hidden hover:shadow-2xl transition-all text-start w-full animate-in zoom-in duration-300"
            >
              <div className="relative aspect-video">
                <img src={lesson.thumbnail} alt={lesson.title[lang]} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                <div className="absolute inset-0 bg-black/20 group-hover:bg-black/0 transition-all flex items-center justify-center">
                  <PlayCircle size={60} className="text-white opacity-0 group-hover:opacity-100 scale-50 group-hover:scale-100 transition-all drop-shadow-2xl" />
                </div>
                <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-md text-blue-900 text-[10px] font-black px-3 py-1.5 rounded-full shadow-xl">
                  {lesson.subject}
                </div>
              </div>
              
              <div className="p-8">
                <h3 className="text-xl font-black text-blue-900 dark:text-white mb-3 group-hover:text-blue-600 transition-colors line-clamp-2">
                  {lesson.title[lang]}
                </h3>
                <div className="flex items-center justify-between pt-6 mt-6 border-t border-gray-100 dark:border-gray-800">
                   <div className="flex items-center gap-2 text-gray-400 text-xs font-bold">
                      <Clock size={14}/> {lesson.duration}
                   </div>
                   <span className="text-blue-600 font-black text-sm group-hover:translate-x-[-5px] transition-transform">بدء المشاهدة</span>
                </div>
              </div>
            </button>
          ))}
          
          {filteredLessons.length === 0 && (
            <div className="col-span-full py-32 text-center">
              <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto text-gray-400 mb-6"><Search size={40} /></div>
              <p className="text-xl font-black text-gray-500">لا توجد محاضرات في هذا القسم حالياً</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Lessons;
