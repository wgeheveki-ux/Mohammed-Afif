
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Users, Book, Video, Folder, Plus, Trash2, 
  LayoutDashboard, LogOut, X, Menu, Bell,
  MessageSquare, ShieldCheck, Globe, Zap, 
  CheckCircle2, Search, Filter, MoreVertical,
  ChevronRight, Award, Clock, Sparkles
} from 'lucide-react';
import { Language, Subject, Difficulty, Lesson } from '../types';
import { MOCK_LESSONS } from '../constants';

interface AdminDashboardProps {
  t: any;
  lang: Language;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ t, lang }) => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('الرئيسية');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [sections, setSections] = useState<string[]>([]);
  const [stats, setStats] = useState({ students: 2450, messages: 12, subscriptions: 5 });

  const [showAddLesson, setShowAddLesson] = useState(false);
  const [showAddSection, setShowAddSection] = useState(false);

  const [newSection, setNewSection] = useState('');
  const [newLesson, setNewLesson] = useState({
    titleAr: '', subject: '', videoUrl: '', thumbnail: '', description: ''
  });

  const LOGO_URL = "https://i.ibb.co/6JH2hqLC/JPEG-6137224863898630761.jpg";

  useEffect(() => {
    const loadInitialData = () => {
      const savedLessons = localStorage.getItem('afifi_lessons');
      const savedSections = localStorage.getItem('afifi_sections');

      if (savedLessons) {
        setLessons(JSON.parse(savedLessons));
      } else {
        setLessons(MOCK_LESSONS);
        localStorage.setItem('afifi_lessons', JSON.stringify(MOCK_LESSONS));
      }

      if (savedSections) {
        setSections(JSON.parse(savedSections));
      } else {
        const initialSections = ['الجبر', 'الهندسة الفراغية', 'التفاضل', 'التكامل'];
        setSections(initialSections);
        localStorage.setItem('afifi_sections', JSON.stringify(initialSections));
      }
    };

    loadInitialData();
  }, []);

  const notifyUpdate = () => {
    window.dispatchEvent(new Event('storage'));
    window.dispatchEvent(new CustomEvent('afifi_data_updated'));
  };

  const syncData = (updatedLessons: Lesson[], updatedSections: string[]) => {
    setLessons([...updatedLessons]);
    setSections([...updatedSections]);
    localStorage.setItem('afifi_lessons', JSON.stringify(updatedLessons));
    localStorage.setItem('afifi_sections', JSON.stringify(updatedSections));
    notifyUpdate();
  };

  const handleAddSection = () => {
    if (!newSection.trim()) return;
    if (sections.includes(newSection.trim())) {
      alert('هذا القسم موجود بالفعل!');
      return;
    }
    const updated = [...sections, newSection.trim()];
    syncData(lessons, updated);
    setNewSection('');
    setShowAddSection(false);
  };

  const handleAddLesson = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLesson.titleAr || !newLesson.subject || !newLesson.videoUrl) return;

    let finalVideoUrl = newLesson.videoUrl;
    if (finalVideoUrl.includes('watch?v=')) {
      finalVideoUrl = finalVideoUrl.replace('watch?v=', 'embed/');
    }

    const lesson: Lesson = {
      id: `lesson-${Date.now()}`,
      title: { ar: newLesson.titleAr, en: newLesson.titleAr },
      subject: newLesson.subject as Subject,
      difficulty: Difficulty.MEDIUM,
      videoUrl: finalVideoUrl,
      pdfUrl: '#',
      duration: '15:00',
      isPremium: true,
      thumbnail: newLesson.thumbnail || 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?auto=format&fit=crop&q=80&w=800',
      description: { ar: newLesson.description || 'لا يوجد وصف متاح.', en: newLesson.description || 'No description available.' }
    };
    const updated = [...lessons, lesson];
    syncData(updated, sections);
    setShowAddLesson(false);
    setNewLesson({ titleAr: '', subject: '', videoUrl: '', thumbnail: '', description: '' });
  };

  const deleteLesson = (id: string) => {
    if (window.confirm('هل أنت متأكد من حذف هذه المحاضرة نهائياً؟')) {
      const updated = lessons.filter(l => l.id !== id);
      syncData(updated, sections);
    }
  };

  const deleteSection = (name: string) => {
    if (window.confirm(`هل أنت متأكد من حذف قسم "${name}"؟`)) {
      const updated = sections.filter(s => s !== name);
      syncData(lessons, updated);
    }
  };

  const menuItems = [
    { id: 'الرئيسية', icon: LayoutDashboard, label: 'لوحة التحكم' },
    { id: 'الأقسام', icon: Folder, label: 'إدارة الأقسام' },
    { id: 'المحاضرات', icon: Video, label: 'المحاضرات' },
    { id: 'الطلاب', icon: Users, label: 'الطلاب المسجلين' },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'الرئيسية':
        return (
          <div className="space-y-8 animate-in fade-in duration-500">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white dark:bg-gray-900 p-8 rounded-[2.5rem] border border-gray-100 dark:border-gray-800 shadow-sm flex items-center gap-6">
                <div className="w-16 h-16 bg-blue-50 dark:bg-blue-900/20 text-blue-600 rounded-3xl flex items-center justify-center shadow-inner"><Folder size={32}/></div>
                <div>
                  <p className="text-gray-400 text-[10px] font-black uppercase tracking-widest">الأقسام</p>
                  <h3 className="text-3xl font-black">{sections.length}</h3>
                </div>
              </div>
              <div className="bg-white dark:bg-gray-900 p-8 rounded-[2.5rem] border border-gray-100 dark:border-gray-800 shadow-sm flex items-center gap-6">
                <div className="w-16 h-16 bg-green-50 dark:bg-green-900/20 text-green-600 rounded-3xl flex items-center justify-center shadow-inner"><Video size={32}/></div>
                <div>
                  <p className="text-gray-400 text-[10px] font-black uppercase tracking-widest">المحاضرات</p>
                  <h3 className="text-3xl font-black">{lessons.length}</h3>
                </div>
              </div>
              <div className="bg-white dark:bg-gray-900 p-8 rounded-[2.5rem] border border-gray-100 dark:border-gray-800 shadow-sm flex items-center gap-6">
                <div className="w-16 h-16 bg-amber-50 dark:bg-amber-900/20 text-amber-600 rounded-3xl flex items-center justify-center shadow-inner"><Users size={32}/></div>
                <div>
                  <p className="text-gray-400 text-[10px] font-black uppercase tracking-widest">الطلاب</p>
                  <h3 className="text-3xl font-black">{stats.students}</h3>
                </div>
              </div>
              <div className="bg-blue-900 p-8 rounded-[2.5rem] text-white shadow-2xl shadow-blue-500/20 flex items-center gap-6 border border-blue-800">
                <div className="w-16 h-16 bg-white/10 rounded-3xl flex items-center justify-center text-white shadow-lg"><Zap size={32}/></div>
                <div>
                  <p className="text-blue-300 text-[10px] font-black uppercase tracking-widest">النمو</p>
                  <h3 className="text-3xl font-black">+14</h3>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
               <div className="bg-white dark:bg-gray-900 rounded-[3rem] p-10 border border-gray-100 dark:border-gray-800 shadow-sm">
                  <h3 className="text-2xl font-black text-blue-900 dark:text-white mb-8">آخر المحاضرات المنشورة</h3>
                  <div className="space-y-5">
                     {lessons.length > 0 ? lessons.slice(-4).reverse().map(l => (
                       <div key={l.id} className="flex items-center justify-between p-5 bg-gray-50 dark:bg-gray-800/50 rounded-2xl group hover:bg-blue-50 transition-all">
                          <div className="flex items-center gap-4">
                            <img src={l.thumbnail} className="w-14 h-14 rounded-2xl object-cover shadow-md" />
                            <div>
                               <p className="font-black text-gray-800 dark:text-white">{l.title.ar}</p>
                               <p className="text-[10px] text-blue-600 font-black tracking-widest">{l.subject}</p>
                            </div>
                          </div>
                          <button onClick={() => deleteLesson(l.id)} className="p-3 text-red-400 hover:bg-red-50 hover:text-red-600 rounded-xl transition-all opacity-0 group-hover:opacity-100"><Trash2 size={20}/></button>
                       </div>
                     )) : (
                        <p className="text-center py-10 text-gray-400 font-bold">لا يوجد بيانات</p>
                     )}
                  </div>
               </div>

               <div className="bg-blue-950 rounded-[3rem] p-10 text-white relative overflow-hidden flex flex-col justify-center border border-blue-800 shadow-2xl">
                  <div className="absolute top-0 right-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20"></div>
                  <h3 className="text-3xl font-black mb-4 relative z-10">إضافة محتوى حصري</h3>
                  <p className="text-blue-200 mb-10 font-bold relative z-10">تحكم كامل في إمبراطورية الرياضيات الخاصة بك. أضف دروسك وموادك بضغطة واحدة.</p>
                  <div className="grid grid-cols-2 gap-4 relative z-10">
                     <button onClick={() => setShowAddSection(true)} className="py-5 bg-white text-blue-900 rounded-[2rem] font-black hover:bg-blue-50 transition-all flex items-center justify-center gap-3 shadow-xl">
                        <Folder size={24}/>
                        مادة جديدة
                     </button>
                     <button onClick={() => setShowAddLesson(true)} className="py-5 bg-blue-600 text-white rounded-[2rem] font-black hover:bg-blue-700 transition-all flex items-center justify-center gap-3 shadow-xl border border-blue-500">
                        <Plus size={24}/>
                        محاضرة
                     </button>
                  </div>
               </div>
            </div>
          </div>
        );
      case 'الأقسام':
        return (
          <div className="bg-white dark:bg-gray-900 rounded-[3rem] p-10 border border-gray-100 dark:border-gray-800 animate-in fade-in duration-500">
             <div className="flex items-center justify-between mb-12">
                <h3 className="text-3xl font-black text-blue-900 dark:text-white">تخطيط المنهج</h3>
                <button onClick={() => setShowAddSection(true)} className="px-8 py-4 bg-blue-600 text-white rounded-[2rem] font-black flex items-center gap-3 shadow-xl">
                  <Plus size={24}/> إضافة مادة
                </button>
             </div>
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {sections.map(s => (
                  <div key={s} className="p-8 bg-gray-50 dark:bg-gray-800 rounded-[2.5rem] flex items-center justify-between group border-2 border-transparent hover:border-blue-200 transition-all">
                     <div className="flex items-center gap-5">
                        <div className="w-14 h-14 bg-blue-100 text-blue-700 rounded-2xl flex items-center justify-center font-black text-xl shadow-inner">{s.charAt(0)}</div>
                        <span className="font-black text-gray-800 dark:text-white text-lg">{s}</span>
                     </div>
                     <button onClick={() => deleteSection(s)} className="p-3 text-red-400 hover:text-red-600 opacity-0 group-hover:opacity-100 transition-all"><Trash2 size={20}/></button>
                  </div>
                ))}
             </div>
          </div>
        );
      case 'المحاضرات':
        return (
          <div className="bg-white dark:bg-gray-900 rounded-[3rem] p-10 border border-gray-100 dark:border-gray-800 animate-in fade-in duration-500">
             <div className="flex items-center justify-between mb-12">
                <h3 className="text-3xl font-black text-blue-900 dark:text-white">خزانة المحاضرات</h3>
                <button onClick={() => setShowAddLesson(true)} className="px-8 py-4 bg-blue-700 text-white rounded-[2rem] font-black flex items-center gap-3 shadow-xl">
                  <Plus size={24}/> رفع محاضرة
                </button>
             </div>
             <div className="overflow-x-auto">
                <table className="w-full text-right">
                   <thead>
                      <tr className="bg-gray-50 dark:bg-gray-800/50 text-[10px] font-black text-gray-400 uppercase tracking-widest">
                         <th className="px-8 py-6 rounded-r-[2rem]">المحاضرة</th>
                         <th className="px-8 py-6 text-center">القسم</th>
                         <th className="px-8 py-6 text-center">الحالة</th>
                         <th className="px-8 py-6 rounded-l-[2rem] text-center">الإجراءات</th>
                      </tr>
                   </thead>
                   <tbody className="divide-y dark:divide-gray-800">
                      {lessons.map(l => (
                        <tr key={l.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/20 transition-all group">
                           <td className="px-8 py-6 flex items-center gap-5">
                              <img src={l.thumbnail} className="w-16 h-12 rounded-xl object-cover shadow-sm" />
                              <span className="font-black text-gray-800 dark:text-white">{l.title.ar}</span>
                           </td>
                           <td className="px-8 py-6 text-center">
                              <span className="px-4 py-1.5 bg-blue-50 text-blue-700 rounded-full text-[10px] font-black border border-blue-100">{l.subject}</span>
                           </td>
                           <td className="px-8 py-6 text-center">
                              <span className="text-green-600 font-black text-xs inline-flex items-center gap-2"><CheckCircle2 size={16}/> منشورة</span>
                           </td>
                           <td className="px-8 py-6 text-center">
                              <button onClick={() => deleteLesson(l.id)} className="p-3 text-red-400 hover:bg-red-50 rounded-2xl transition-all"><Trash2 size={20}/></button>
                           </td>
                        </tr>
                      ))}
                   </tbody>
                </table>
             </div>
          </div>
        );
      default:
        return <div className="py-20 text-center font-black text-gray-400">قريباً...</div>;
    }
  };

  return (
    <div className="bg-[#F8F9FA] dark:bg-gray-950 min-h-screen flex font-cairo overflow-x-hidden">
      <aside className={`fixed inset-y-0 right-0 z-[100] w-80 bg-white dark:bg-gray-900 border-l dark:border-gray-800 shadow-2xl transition-transform duration-300 lg:relative lg:translate-x-0 ${isSidebarOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="flex flex-col h-full p-8">
          <div className="flex items-center justify-between mb-12">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center overflow-hidden border-2 border-blue-50 shadow-xl">
                 <img src={LOGO_URL} alt="Logo" className="w-full h-full object-cover" />
              </div>
              <div className="flex flex-col">
                <h2 className="text-xl font-black text-blue-900 dark:text-white leading-none">إدارة عفيفي</h2>
                <span className="text-[10px] font-black text-blue-600 uppercase tracking-tighter">Empire Control</span>
              </div>
            </div>
            <button onClick={() => setIsSidebarOpen(false)} className="lg:hidden p-2 text-gray-400"><X size={24} /></button>
          </div>
          <nav className="flex-1 space-y-3 overflow-y-auto">
            {menuItems.map(item => (
              <button key={item.id} onClick={() => setActiveTab(item.id)} className={`w-full flex items-center gap-5 px-5 py-4 rounded-[1.5rem] font-black text-sm transition-all ${activeTab === item.id ? 'bg-blue-600 text-white shadow-xl shadow-blue-500/20' : 'text-gray-500 hover:bg-gray-50 hover:text-blue-600'}`}>
                <item.icon size={22} />
                {item.label}
              </button>
            ))}
            <div className="pt-10 border-t dark:border-gray-800 mt-6">
              <button onClick={() => navigate('/')} className="w-full flex items-center gap-5 px-5 py-4 rounded-[1.5rem] font-black text-sm text-blue-700 bg-blue-50 dark:bg-blue-900/20 shadow-inner">
                <Globe size={22}/> عرض الموقع العام
              </button>
            </div>
          </nav>
          <div className="pt-8 mt-auto border-t dark:border-gray-800">
             <button onClick={() => navigate('/auth')} className="w-full flex items-center gap-5 px-5 py-5 rounded-[1.5rem] font-black text-sm text-red-500 hover:bg-red-50 transition-all"><LogOut size={22}/> إغلاق الجلسة</button>
          </div>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <header className="px-10 py-8 flex items-center justify-between sticky top-0 bg-[#F8F9FA]/80 backdrop-blur-md z-40 border-b border-gray-100">
           <div className="flex items-center gap-6">
              <button onClick={() => setIsSidebarOpen(true)} className="lg:hidden p-4 bg-white rounded-2xl shadow-sm"><Menu size={24}/></button>
              <h1 className="text-4xl font-black text-blue-900 dark:text-white hidden lg:block tracking-tighter">{activeTab}</h1>
           </div>
           <div className="flex items-center gap-6">
              <div className="text-right hidden sm:block">
                 <p className="text-base font-black text-blue-900">م/ محمد عفيفي</p>
                 <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">مؤسس الإمبراطورية</p>
              </div>
              <div className="w-14 h-14 bg-white rounded-2xl border-4 border-white shadow-2xl overflow-hidden">
                 <img src={LOGO_URL} className="w-full h-full object-cover" />
              </div>
           </div>
        </header>
        <main className="flex-1 p-10 max-w-7xl mx-auto w-full">
           {renderContent()}
        </main>
      </div>

      {showAddSection && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center p-6 bg-blue-950/40 backdrop-blur-sm animate-in fade-in">
           <div className="bg-white dark:bg-gray-900 w-full max-w-md rounded-[3rem] p-10 shadow-2xl space-y-8 animate-in zoom-in duration-300">
              <h3 className="text-3xl font-black text-blue-900">تأسيس مادة جديدة</h3>
              <input type="text" value={newSection} onChange={e => setNewSection(e.target.value)} placeholder="اسم المادة العلمية" className="w-full p-5 bg-gray-50 dark:bg-gray-800 rounded-2xl font-black border-none ring-2 ring-gray-100 focus:ring-blue-600 transition-all" />
              <div className="flex gap-4">
                 <button onClick={handleAddSection} className="flex-1 py-5 bg-blue-600 text-white rounded-[1.5rem] font-black shadow-xl">حفظ</button>
                 <button onClick={() => setShowAddSection(false)} className="flex-1 py-5 bg-gray-100 text-gray-500 rounded-[1.5rem] font-black">إلغاء</button>
              </div>
           </div>
        </div>
      )}

      {showAddLesson && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center p-6 bg-blue-950/40 backdrop-blur-sm animate-in fade-in overflow-y-auto">
           <div className="bg-white dark:bg-gray-900 w-full max-w-2xl rounded-[3.5rem] p-12 shadow-2xl my-10 relative animate-in zoom-in duration-300">
              <button onClick={() => setShowAddLesson(false)} className="absolute top-10 right-10 text-gray-400 hover:text-red-500"><X size={28}/></button>
              <h3 className="text-4xl font-black text-blue-900 mb-10 tracking-tighter">بناء محاضرة جديدة</h3>
              <form onSubmit={handleAddLesson} className="space-y-8">
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-3">
                       <label className="text-xs font-black text-gray-400 uppercase tracking-widest">عنوان المحاضرة</label>
                       <input required type="text" value={newLesson.titleAr} onChange={e => setNewLesson({...newLesson, titleAr: e.target.value})} className="w-full p-5 bg-gray-50 dark:bg-gray-800 rounded-2xl font-black focus:ring-2 focus:ring-blue-600 outline-none" />
                    </div>
                    <div className="space-y-3">
                       <label className="text-xs font-black text-gray-400 uppercase tracking-widest">الركن التابع له</label>
                       <select required value={newLesson.subject} onChange={e => setNewLesson({...newLesson, subject: e.target.value})} className="w-full p-5 bg-gray-50 dark:bg-gray-800 rounded-2xl font-black appearance-none focus:ring-2 focus:ring-blue-600 outline-none">
                          <option value="">اختر القسم</option>
                          {sections.map(s => <option key={s} value={s}>{s}</option>)}
                       </select>
                    </div>
                 </div>
                 <div className="space-y-3">
                    <label className="text-xs font-black text-gray-400 uppercase tracking-widest">رابط الفيديو (YouTube)</label>
                    <input required type="url" value={newLesson.videoUrl} onChange={e => setNewLesson({...newLesson, videoUrl: e.target.value})} className="w-full p-5 bg-gray-50 dark:bg-gray-800 rounded-2xl font-black focus:ring-2 focus:ring-blue-600 outline-none" />
                 </div>
                 <div className="space-y-3">
                    <label className="text-xs font-black text-gray-400 uppercase tracking-widest">وصف المحتوى</label>
                    <textarea value={newLesson.description} onChange={e => setNewLesson({...newLesson, description: e.target.value})} className="w-full p-5 bg-gray-50 dark:bg-gray-800 rounded-2xl font-black h-32 focus:ring-2 focus:ring-blue-600 outline-none" />
                 </div>
                 <button type="submit" className="w-full py-6 bg-blue-700 text-white rounded-[2rem] font-black text-2xl shadow-2xl shadow-blue-200">نشر المحاضرة للإمبراطورية</button>
              </form>
           </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
