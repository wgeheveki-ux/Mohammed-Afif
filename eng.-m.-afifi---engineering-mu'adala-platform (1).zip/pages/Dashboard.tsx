
import React, { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  BarChart2, Award, BookOpen, 
  Settings, LogOut, CheckCircle, TrendingUp, Trophy
} from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts';
import { User, Language, Lesson } from '../types';

interface DashboardProps {
  t: any;
  lang: Language;
  user: User | null;
}

const Dashboard: React.FC<DashboardProps> = ({ t, lang, user }) => {
  const navigate = useNavigate();

  const totalLessonsCount = useMemo(() => {
    const saved = localStorage.getItem('afifi_lessons');
    if (saved) return JSON.parse(saved).length;
    return 10;
  }, []);

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-gray-50 dark:bg-gray-950 transition-colors">
        <div className="w-24 h-24 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center mb-6 text-blue-600 dark:text-blue-400">
          <BookOpen size={48} />
        </div>
        <h2 className="text-2xl font-bold mb-4 dark:text-white">يرجى تسجيل الدخول أولاً</h2>
        <button 
          onClick={() => navigate('/auth')}
          className="bg-blue-700 text-white px-8 py-3 rounded-xl font-bold hover:bg-blue-800 transition-all shadow-lg"
        >
          {t.login}
        </button>
      </div>
    );
  }

  const completedCount = user.progress.completedLessons.length;
  const progressPercentage = totalLessonsCount > 0 ? Math.round((completedCount / totalLessonsCount) * 100) : 0;

  const dataPie = [
    { name: 'Completed', value: completedCount },
    { name: 'Remaining', value: Math.max(0, totalLessonsCount - completedCount) },
  ];
  
  const COLORS = ['#3b82f6', '#e5e7eb'];
  const DARK_COLORS = ['#3b82f6', '#374151'];

  const quizData = [
    { name: 'الجبر', score: 85 },
    { name: 'الفراغية', score: 72 },
    { name: 'التفاضل', score: 90 },
    { name: 'التكامل', score: 65 },
  ];

  return (
    <div className="bg-gray-50 dark:bg-gray-950 min-h-screen pb-20 transition-colors font-cairo">
      <div className="bg-blue-900 dark:bg-gray-900 pt-32 pb-48 px-4 sm:px-6 lg:px-8 -mt-20 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-600/20 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2"></div>
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8 relative z-10">
          <div className="flex items-center gap-6">
            <div className="w-24 h-24 rounded-[2rem] bg-blue-600 border-4 border-blue-500/50 shadow-2xl flex items-center justify-center text-4xl text-white font-black uppercase">
              {user.name.charAt(0)}
            </div>
            <div className="text-white">
              <h1 className="text-3xl font-black mb-2">{user.name}</h1>
              <p className="text-blue-200 dark:text-blue-400 flex items-center gap-2 font-bold">
                <Award size={18} />
                طالب معادلة • مستوى {user.progress.totalPoints > 500 ? 'متقدم' : 'مبتدئ'}
              </p>
            </div>
          </div>
          
          <div className="flex gap-4">
            <button className="bg-white/10 hover:bg-white/20 p-3 rounded-2xl text-white backdrop-blur-md transition-all border border-white/20">
              <Settings size={24} />
            </button>
            <button onClick={() => navigate('/')} className="bg-red-500/10 hover:bg-red-500/20 p-3 rounded-2xl text-red-400 backdrop-blur-md transition-all border border-red-500/20">
              <LogOut size={24} />
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-32 relative z-20">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div className="bg-white dark:bg-gray-900 p-8 rounded-[2.5rem] shadow-xl border border-gray-100 dark:border-gray-800 relative overflow-hidden group">
               <div className="absolute top-0 right-0 w-24 h-24 bg-blue-50 dark:bg-blue-900/10 rounded-bl-full -z-10 transition-all group-hover:scale-110"></div>
               <div className="flex items-center justify-between mb-4">
                  <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded-2xl text-blue-600 dark:text-blue-400">
                    <TrendingUp size={24} />
                  </div>
                  <span className="text-green-500 font-black text-sm">+12%</span>
               </div>
               <h3 className="text-gray-500 dark:text-gray-400 font-bold mb-1">نقاط الخبرة (XP)</h3>
               <div className="text-4xl font-black text-blue-900 dark:text-white">{user.progress.totalPoints || 0}</div>
            </div>
            
            <div className="bg-white dark:bg-gray-900 p-8 rounded-[2.5rem] shadow-xl border border-gray-100 dark:border-gray-800 relative overflow-hidden group">
               <div className="absolute top-0 right-0 w-24 h-24 bg-green-50 dark:bg-green-900/10 rounded-bl-full -z-10 transition-all group-hover:scale-110"></div>
               <div className="flex items-center justify-between mb-4">
                  <div className="p-3 bg-green-100 dark:bg-green-900/30 rounded-2xl text-green-600 dark:text-green-400">
                    <CheckCircle size={24} />
                  </div>
               </div>
               <h3 className="text-gray-500 dark:text-gray-400 font-bold mb-1">الدروس المكتملة</h3>
               <div className="text-4xl font-black text-blue-900 dark:text-white">{completedCount}</div>
            </div>

            <div className="bg-white dark:bg-gray-900 p-8 rounded-[2.5rem] shadow-xl border border-gray-100 dark:border-gray-800 sm:col-span-2">
              <h3 className="text-xl font-black text-blue-900 dark:text-white mb-8 flex items-center gap-2">
                <BarChart2 size={24} className="text-blue-600" />
                أداء الاختبارات الأخيرة
              </h3>
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={quizData}>
                    <XAxis dataKey="name" fontSize={12} stroke="#94a3b8" fontWeight="bold" />
                    <YAxis fontSize={12} stroke="#94a3b8" fontWeight="bold" />
                    <Tooltip 
                      contentStyle={{ 
                        backgroundColor: '#1e3a8a', 
                        borderColor: '#1e40af', 
                        color: '#fff', 
                        borderRadius: '16px',
                        border: 'none',
                        boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1)' 
                      }} 
                    />
                    <Bar dataKey="score" fill="#3b82f6" radius={[10, 10, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          <div className="space-y-8">
            <div className="bg-white dark:bg-gray-900 p-8 rounded-[2.5rem] shadow-xl border border-gray-100 dark:border-gray-800 flex flex-col items-center text-center">
              <h3 className="text-lg font-black text-blue-900 dark:text-white mb-6">إجمالي التقدم</h3>
              <div className="h-48 w-48 relative mb-6">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={dataPie}
                      innerRadius={65}
                      outerRadius={85}
                      paddingAngle={8}
                      dataKey="value"
                      stroke="none"
                    >
                      {dataPie.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={localStorage.getItem('theme') === 'dark' ? DARK_COLORS[index % DARK_COLORS.length] : COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
                <div className="absolute inset-0 flex items-center justify-center flex-col">
                  <span className="text-4xl font-black text-blue-700 dark:text-blue-400">{progressPercentage}%</span>
                  <span className="text-[10px] text-gray-500 dark:text-gray-500 font-black uppercase tracking-widest">Progress</span>
                </div>
              </div>
              <p className="text-sm text-gray-500 dark:text-gray-400 font-bold leading-relaxed">
                لقد أكملت {completedCount} درساً من إجمالي {totalLessonsCount} محاضرات متاحة حالياً.
              </p>
              <button onClick={() => navigate('/lessons')} className="mt-8 w-full bg-blue-700 text-white py-4 rounded-2xl font-black hover:bg-blue-800 transition-all shadow-lg active:scale-95">
                متابعة الدروس
              </button>
            </div>

            <div className="bg-white dark:bg-gray-900 p-8 rounded-[2.5rem] shadow-xl border border-gray-100 dark:border-gray-800">
               <h3 className="text-lg font-black text-blue-900 dark:text-white mb-6 flex items-center gap-2">
                  <Trophy size={20} className="text-yellow-500" />
                  لوحة الشرف (أعلى الطلاب)
               </h3>
               <div className="space-y-4">
                  {[
                    { name: 'أحمد محمود', points: 2450, rank: 1 },
                    { name: 'سارة علي', points: 2100, rank: 2 },
                    { name: 'ياسين كمال', points: 1980, rank: 3 },
                  ].map(p => (
                    <div key={p.rank} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800/50 rounded-2xl border border-transparent hover:border-blue-100 transition-all">
                       <div className="flex items-center gap-3">
                          <span className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-black shadow-sm ${
                            p.rank === 1 ? 'bg-yellow-400 text-yellow-900' : 
                            p.rank === 2 ? 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200' : 'bg-amber-600 text-white'
                          }`}>
                            {p.rank}
                          </span>
                          <span className="font-bold text-gray-800 dark:text-gray-200 text-sm">{p.name}</span>
                       </div>
                       <span className="text-blue-600 dark:text-blue-400 font-black text-sm">{p.points} XP</span>
                    </div>
                  ))}
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
