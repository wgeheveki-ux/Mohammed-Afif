
import React, { useState, useRef, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { 
  Play, Download, ChevronRight, Sparkles, Send, 
  CheckCircle, Award, Image as ImageIcon, X, Loader2, Lock, Eye
} from 'lucide-react';
import { MOCK_LESSONS } from '../constants';
import { Language, User, Lesson } from '../types';
import { geminiService } from '../services/geminiService';

interface LessonDetailProps {
  t: any;
  lang: Language;
  user: User | null;
}

const LessonDetail: React.FC<LessonDetailProps> = ({ t, lang, user }) => {
  const { id } = useParams();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [lesson, setLesson] = useState<Lesson | null>(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiResponse, setAiResponse] = useState<string | null>(null);
  const [question, setQuestion] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [relatedLessons, setRelatedLessons] = useState<Lesson[]>([]);

  useEffect(() => {
    // Load lessons from localStorage to include newly added ones
    const savedLessons = localStorage.getItem('afifi_lessons');
    const allLessons: Lesson[] = savedLessons ? JSON.parse(savedLessons) : MOCK_LESSONS;
    
    const found = allLessons.find(l => l.id === id);
    setLesson(found || null);
    
    // Set related lessons
    if (found) {
      setRelatedLessons(allLessons.filter(l => l.id !== id && l.subject === found.subject).slice(0, 4));
    } else {
      setRelatedLessons(allLessons.filter(l => l.id !== id).slice(0, 4));
    }
  }, [id]);

  if (!lesson) return (
    <div className="p-20 text-center dark:text-white flex flex-col items-center gap-6">
      <div className="w-20 h-20 bg-red-100 dark:bg-red-900/30 text-red-600 rounded-full flex items-center justify-center">
        <X size={40} />
      </div>
      <h2 className="text-2xl font-black">الدرس غير موجود</h2>
      <p className="text-gray-500">ربما تم حذفه أو أن الرابط غير صحيح.</p>
      <button onClick={() => navigate('/lessons')} className="px-8 py-3 bg-blue-700 text-white rounded-xl font-bold">العودة للدروس</button>
    </div>
  );

  const isLocked = lesson.isPremium && (!user || !user.isPremium);

  const handleActionWithPremiumCheck = (action: () => void) => {
    if (isLocked) {
      alert(lang === 'ar' ? 'عليك الاشتراك أولاً للوصول إلى هذا المحتوى!' : 'You must subscribe first to access this content!');
      navigate('/pricing');
      return;
    }
    action();
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAskAi = async () => {
    if (!question.trim() && !selectedImage) return;
    
    setAiLoading(true);
    setAiResponse(null);
    
    try {
      const explanation = await geminiService.getMathExplanation(question, lang, selectedImage || undefined);
      setAiResponse(explanation || null);
    } catch (error) {
      setAiResponse(lang === 'ar' ? "فشل الاتصال بالمساعد الذكي." : "Failed to connect to AI assistant.");
    } finally {
      setAiLoading(false);
    }
  };

  const clearImage = () => {
    setSelectedImage(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="bg-gray-50 dark:bg-gray-950 min-h-screen pb-20 transition-colors font-cairo">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-gray-500 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 font-bold mb-8 group">
          <ChevronRight className="group-hover:translate-x-1 transition-transform rtl:rotate-180" />
          العودة للدروس
        </button>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content Area */}
          <div className="lg:col-span-2 space-y-8">
            <div className="bg-white dark:bg-gray-900 rounded-3xl overflow-hidden shadow-xl border border-gray-100 dark:border-gray-800 ring-1 ring-black/5">
              <div className="aspect-video relative group bg-black">
                {isLocked ? (
                  <div className="absolute inset-0 z-20 bg-gray-900/80 backdrop-blur-md flex flex-col items-center justify-center p-8 text-center text-white">
                    <div className="w-20 h-20 bg-amber-500 rounded-[2rem] flex items-center justify-center mb-6 shadow-2xl animate-pulse">
                      <Lock size={40} />
                    </div>
                    <h3 className="text-2xl font-black mb-3">هذا المحتوى مخصص للمشتركين فقط</h3>
                    <p className="text-gray-300 mb-8 max-w-sm font-medium">اشترك الآن في باقة المهندس محمد عفيفي لتتمكن من مشاهدة كافة دروس المعادلة والتدريبات الحصرية.</p>
                    <button 
                      onClick={() => navigate('/pricing')}
                      className="px-10 py-4 bg-blue-600 text-white rounded-2xl font-black hover:bg-blue-700 transition-all shadow-xl active:scale-95"
                    >
                      اشترك الآن وشاهد الفيديو
                    </button>
                  </div>
                ) : (
                  <iframe 
                    width="100%" 
                    height="100%" 
                    src={lesson.videoUrl} 
                    title="Video Player"
                    frameBorder="0" 
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                    allowFullScreen
                  ></iframe>
                )}
                {isLocked && (
                  <img 
                    src={lesson.thumbnail} 
                    className="absolute inset-0 w-full h-full object-cover -z-10 opacity-50 grayscale"
                    alt=""
                  />
                )}
              </div>
              
              <div className="p-8">
                <div className="flex items-center gap-3 mb-4">
                  <span className="px-3 py-1 bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400 rounded-full text-xs font-bold">{lesson.subject}</span>
                  <span className="text-gray-400 dark:text-gray-500 text-sm">{lesson.duration}</span>
                  {lesson.isPremium && <span className="flex items-center gap-1 px-2 py-0.5 bg-amber-100 dark:bg-amber-900/30 text-amber-600 text-[10px] font-black rounded-full"><Lock size={10}/> {t.premium}</span>}
                </div>
                <h1 className="text-3xl font-black text-blue-900 dark:text-white mb-4">{lesson.title[lang]}</h1>
                <p className="text-gray-600 dark:text-gray-400 leading-relaxed mb-8">{lesson.description[lang]}</p>
                
                <div className="flex flex-wrap gap-4">
                  <button 
                    onClick={() => handleActionWithPremiumCheck(() => alert('بدأ تحميل الملف...'))}
                    className={`flex-1 min-w-[160px] flex items-center justify-center gap-2 py-4 rounded-2xl font-bold shadow-lg transition-all active:scale-95 group ${
                      isLocked ? 'bg-gray-100 dark:bg-gray-800 text-gray-400 cursor-not-allowed' : 'bg-blue-700 text-white hover:bg-blue-800'
                    }`}
                  >
                    <Download size={20} className={!isLocked ? "group-hover:bounce" : ""} />
                    تحميل المذكرة (PDF)
                    {isLocked && <Lock size={16} className="opacity-50" />}
                  </button>
                  <button 
                    onClick={() => handleActionWithPremiumCheck(() => navigate(`/quiz/${lesson.id}`))} 
                    className={`flex-1 min-w-[160px] flex items-center justify-center gap-2 py-4 rounded-2xl font-bold shadow-lg transition-all active:scale-95 ${
                      isLocked ? 'bg-gray-100 dark:bg-gray-800 text-gray-400 cursor-not-allowed' : 'bg-green-600 text-white hover:bg-green-700'
                    }`}
                  >
                    <CheckCircle size={20} />
                    بدء الاختبار السريع
                    {isLocked && <Lock size={16} className="opacity-50" />}
                  </button>
                </div>
              </div>
            </div>
            
            {/* AI Assistant Card */}
            <div className="bg-gradient-to-br from-blue-700 to-indigo-900 rounded-[2.5rem] p-8 text-white shadow-2xl relative overflow-hidden group border border-white/10">
               <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/10 rounded-full blur-3xl group-hover:scale-125 transition-transform duration-700"></div>
               <div className="flex items-center gap-4 mb-8">
                  <div className="w-14 h-14 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center shadow-inner border border-white/20">
                    <Sparkles className="text-yellow-300 animate-pulse" size={28} />
                  </div>
                  <div>
                    <h3 className="text-2xl font-black">المساعد الذكي (Vision AI)</h3>
                    <p className="text-blue-100 text-sm font-medium">اسألني نصاً أو صور لي مسألة وسأحلها لك!</p>
                  </div>
               </div>
               
               <div className="space-y-6">
                  {selectedImage && (
                    <div className="relative inline-block animate-in zoom-in fade-in duration-300">
                       <img 
                         src={selectedImage} 
                         className="h-32 w-auto rounded-2xl border-2 border-white/30 shadow-xl object-cover" 
                         alt="Selected math problem" 
                       />
                       <button 
                         onClick={clearImage}
                         className="absolute -top-2 -right-2 bg-red-500 text-white p-1.5 rounded-full shadow-lg hover:bg-red-600 transition-colors"
                       >
                         <X size={14} />
                       </button>
                    </div>
                  )}

                  <div className="bg-white/10 backdrop-blur-md rounded-3xl p-2 flex items-center gap-2 border border-white/20 shadow-inner group-focus-within:ring-2 ring-white/30 transition-all">
                    <input 
                      type="text" 
                      placeholder={lang === 'ar' ? "اكتب سؤالك هنا أو ارفع صورة المسألة..." : "Type your question or upload a problem image..."}
                      className="bg-transparent border-none focus:ring-0 flex-1 px-4 py-3 text-white placeholder:text-blue-200 font-bold"
                      value={question}
                      onChange={(e) => setQuestion(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleAskAi()}
                    />
                    
                    <input 
                      type="file" 
                      accept="image/*" 
                      className="hidden" 
                      ref={fileInputRef}
                      onChange={handleImageChange}
                    />
                    
                    <button 
                      onClick={() => fileInputRef.current?.click()}
                      className="p-3 text-blue-200 hover:text-white hover:bg-white/10 rounded-2xl transition-all"
                    >
                      <ImageIcon size={22} />
                    </button>

                    <button 
                      onClick={handleAskAi}
                      disabled={aiLoading || (!question.trim() && !selectedImage)}
                      className="bg-white text-blue-900 p-4 rounded-2xl font-black hover:bg-blue-50 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-xl active:scale-90 flex items-center justify-center min-w-[56px]"
                    >
                      {aiLoading ? <Loader2 className="animate-spin" size={20} /> : <Send size={22} className="rtl:rotate-180" />}
                    </button>
                  </div>

                  {aiResponse && (
                    <div className="bg-white/10 backdrop-blur-md rounded-3xl p-8 border border-white/20 animate-in fade-in slide-in-from-bottom-4 duration-500 shadow-2xl">
                       <p className="text-base leading-relaxed whitespace-pre-wrap font-medium">{aiResponse}</p>
                    </div>
                  )}
               </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            <div className="bg-white dark:bg-gray-900 rounded-3xl p-6 shadow-xl border border-gray-100 dark:border-gray-800">
               <h3 className="text-lg font-bold text-blue-900 dark:text-white mb-6 flex items-center gap-2">
                  <Play size={18} className="text-blue-600 dark:text-blue-400" />
                  دروس ذات صلة
               </h3>
               <div className="space-y-4">
                  {relatedLessons.length > 0 ? relatedLessons.map(item => (
                    <Link key={item.id} to={`/lesson/${item.id}`} className="flex gap-4 group">
                       <img src={item.thumbnail} className="w-24 h-16 rounded-xl object-cover flex-shrink-0 group-hover:ring-2 ring-blue-500 transition-all" alt="" />
                       <div className="flex flex-col justify-center">
                          <h4 className="text-sm font-bold text-gray-900 dark:text-gray-100 line-clamp-2 leading-tight group-hover:text-blue-600 dark:group-hover:text-blue-400">{item.title[lang]}</h4>
                          <span className="text-[10px] text-gray-400 dark:text-gray-500 font-medium mt-1">{item.duration}</span>
                       </div>
                    </Link>
                  )) : (
                    <p className="text-xs text-gray-400 text-center py-4">لا توجد دروس صلة حالياً</p>
                  )}
               </div>
            </div>

            <div className="bg-blue-50 dark:bg-blue-900/10 rounded-3xl p-8 border border-blue-100 dark:border-blue-900/30 text-center">
               <div className="w-16 h-16 bg-white dark:bg-gray-800 rounded-2xl flex items-center justify-center mx-auto mb-4 text-blue-600 dark:text-blue-400 shadow-sm">
                  <Award size={32} />
               </div>
               <h3 className="text-lg font-bold text-blue-900 dark:text-white mb-2">اختبر معلوماتك</h3>
               <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">أكمل الاختبار السريع لتحصل على نقاط.</p>
               <button 
                onClick={() => handleActionWithPremiumCheck(() => navigate(`/quiz/${lesson.id}`))} 
                className="bg-blue-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg active:scale-95"
               >
                  ابدأ الاختبار
               </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LessonDetail;
