
import React from 'react';
import { Subject, Difficulty, Lesson, Language } from './types';

export const COLORS = {
  primary: '#1e3a8a',
  secondary: '#3b82f6',
  accent: '#fbbf24',
};

export const TRANSLATIONS = {
  ar: {
    brand: "م/ محمد عفيفي",
    muadala: "معادلة كلية الهندسة",
    home: "الرئيسية",
    courses: "الدورات",
    login: "تسجيل الدخول",
    startNow: "ابدأ الآن",
    heroTitle: "طريقك للقمة في رياضيات الهندسة",
    heroSub: "شرح مبسط، تمارين تفاعلية، ومتابعة دقيقة لكل طالب مع المهندس محمد عفيفي.",
    algebra: "الجبر",
    geometry: "الهندسة الفراغية",
    calculus: "قواعد الاشتقاق",
    applied: "التكامل وتطبيقاته",
    premium: "مميز",
    free: "مجاني",
    leaderboard: "لوحة الشرف",
    lessons: "الدروس",
    quizzes: "الاختبارات",
    downloadPDF: "تحميل PDF",
    watchVideo: "مشاهدة الفيديو",
    aiAssistant: "المساعد الذكي",
    switchLang: "English",
    subjects: "المواد العلمية",
    contactUs: "تواصل معنا",
    subscribeNow: "اشترك الآن",
    dashboard: "لوحة التحكم"
  },
  en: {
    brand: "Eng. M. Afifi",
    muadala: "Engineering Muadala",
    home: "Home",
    courses: "Courses",
    login: "Login",
    startNow: "Start Now",
    heroTitle: "Your Path to Excellence in Engineering Math",
    heroSub: "Simplified explanations, interactive exercises, and personalized tracking with Eng. Mohamed Afifi.",
    algebra: "Algebra",
    geometry: "Solid Geometry",
    calculus: "Calculus",
    applied: "Integration & Applications",
    premium: "Premium",
    free: "Free",
    leaderboard: "Leaderboard",
    lessons: "Lessons",
    quizzes: "Quizzes",
    downloadPDF: "Download PDF",
    watchVideo: "Watch Video",
    aiAssistant: "AI Assistant",
    switchLang: "العربية",
    subjects: "Subjects",
    contactUs: "Contact Us",
    subscribeNow: "Subscribe Now",
    dashboard: "Dashboard"
  }
};

export const MOCK_LESSONS: Lesson[] = [
  {
    id: '1',
    title: { ar: 'المصفوفات والمحددات - الجزء الأول', en: 'Matrices and Determinants - Part 1' },
    subject: Subject.ALGEBRA,
    difficulty: Difficulty.EASY,
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    pdfUrl: '#',
    duration: '20:15',
    isPremium: true,
    thumbnail: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?auto=format&fit=crop&q=80&w=800',
    description: { ar: 'شرح أساسيات المصفوفات وكيفية حساب المحددات من الرتبة الثانية والثالثة.', en: 'Explaining matrix basics and calculating 2nd and 3rd order determinants.' }
  },
  {
    id: '3',
    title: { ar: 'معادلة الخط المستقيم في الفراغ', en: 'Equation of a Straight Line in Space' },
    subject: Subject.GEOMETRY,
    difficulty: Difficulty.HARD,
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    pdfUrl: '#',
    duration: '35:20',
    isPremium: true,
    thumbnail: 'https://images.unsplash.com/photo-1509228627152-72ae9ae6848d?auto=format&fit=crop&q=80&w=800',
    description: { ar: 'استنتاج الصور المختلفة لمعادلة الخط المستقيم في الفراغ ثلاثي الأبعاد.', en: 'Deriving different forms of the straight line equation in 3D space.' }
  }
];
