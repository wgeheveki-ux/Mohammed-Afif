
export enum Language {
  AR = 'ar',
  EN = 'en'
}

export enum Subject {
  ALGEBRA = 'algebra',
  GEOMETRY = 'geometry',
  CALCULUS = 'calculus',
  APPLIED = 'applied'
}

export enum Difficulty {
  EASY = 'easy',
  MEDIUM = 'medium',
  HARD = 'hard'
}

export interface Lesson {
  id: string;
  title: Record<Language, string>;
  subject: Subject;
  difficulty: Difficulty;
  videoUrl: string;
  pdfUrl: string;
  duration: string;
  isPremium: boolean;
  thumbnail: string;
  description: Record<Language, string>;
}

export interface Quiz {
  id: string;
  lessonId: string;
  questions: Question[];
}

export interface Question {
  id: string;
  text: Record<Language, string>;
  options: Record<Language, string>[];
  correctIndex: number;
}

export interface UserProgress {
  completedLessons: string[];
  quizScores: Record<string, number>;
  totalPoints: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  isPremium: boolean;
  role: 'student' | 'admin';
  progress: UserProgress;
  sessionId?: string; // Tracks the current active session
}
