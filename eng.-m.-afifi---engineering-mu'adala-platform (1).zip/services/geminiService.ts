
import { GoogleGenAI, Type } from "@google/genai";

// Senior Engineer Fix: Updated to follow the best practices for @google/genai SDK.
// Instantiating the client inside methods ensures it picks up the latest environment configuration.
export class GeminiService {
  async getMathExplanation(concept: string, language: 'ar' | 'en', imageBase64?: string) {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
      const parts: any[] = [{ text: `You are an expert Math Professor for Engineering Muadala students. 
        Analyze the following input and explain it clearly in ${language === 'ar' ? 'Arabic' : 'English'}. 
        Prompt: ${concept || "Please solve and explain the math problem in this image."}` }];

      if (imageBase64) {
        const base64Data = imageBase64.split(',')[1] || imageBase64;
        parts.push({
          inlineData: {
            mimeType: "image/jpeg",
            data: base64Data
          }
        });
      }

      // Math tasks are complex reasoning tasks, so gemini-3-pro-preview is the recommended model.
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: { parts },
        config: {
          thinkingConfig: { thinkingBudget: 0 }
        }
      });

      // Guidelines specify accessing .text as a property, not calling it as a method.
      return response.text || (language === 'ar' ? "عذراً، لم أتمكن من الحصول على إجابة." : "Sorry, I couldn't get an answer.");
    } catch (error) {
      console.error("Gemini Error:", error);
      return language === 'ar' ? "عذراً، حدث خطأ." : "Sorry, an error occurred.";
    }
  }

  async generateStudyPlan(goals: string) {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: `Create a detailed study plan for the following goals: ${goals}`,
        config: {
            responseMimeType: "application/json",
            // Recommended approach is using responseSchema with the Type enum.
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                plan: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      week: { type: Type.STRING },
                      topics: { type: Type.ARRAY, items: { type: Type.STRING } },
                      tasks: { type: Type.ARRAY, items: { type: Type.STRING } }
                    },
                    required: ["week", "topics", "tasks"]
                  }
                }
              },
              required: ["plan"]
            }
        }
      });
      return response.text;
    } catch (error) {
      console.error("Gemini Error (Study Plan):", error);
      return null;
    }
  }
}

export const geminiService = new GeminiService();
